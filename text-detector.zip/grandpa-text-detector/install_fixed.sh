#!/bin/bash

echo "🔧 Installing Grandpa Text Detector dependencies for Python 3.12..."

# Create virtual environment if not exists
if [ ! -d "venv" ]; then
    echo "📦 Creating virtual environment..."
    python -m venv venv
fi

# Activate virtual environment
source venv/bin/activate

# Upgrade pip and build tools
echo "🔨 Installing build tools..."
pip install --upgrade pip setuptools wheel

# Install numpy first (separately to handle compilation)
echo "📊 Installing numpy..."
pip install numpy==1.26.3

# Install remaining packages
echo "📚 Installing web framework..."
pip install fastapi==0.110.0 uvicorn[standard]==0.29.0 python-multipart==0.0.9

echo "📄 Installing file processors..."
pip install PyPDF2==3.0.1 python-docx==1.1.0

echo "🧠 Installing NLP packages..."
pip install nltk==3.8.1 spacy==3.7.4

echo "📊 Installing pandas and scikit-learn..."
pip install pandas==2.2.0 scikit-learn==1.4.0

# Download NLTK data
echo "📥 Downloading NLTK data..."
python -c "import nltk; nltk.download('punkt')"
python -c "import nltk; nltk.download('punkt_tab')"  # Additional for NLTK 3.8.1

# Download spaCy model - FIXED URL
echo "📥 Downloading spaCy model..."
python -m spacy download en_core_web_sm

echo "✅ Installation complete!"
echo "🚀 Run the app with: python app.py"
