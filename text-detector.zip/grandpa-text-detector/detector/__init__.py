"""
Grandpa Text Detector Package
A comprehensive rule-based AI text detection system
"""

from .scoring.calculator import GrandpaDetector
from .core.statistical import StatisticalAnalyzer
from .core.linguistic import LinguisticAnalyzer
from .core.rhetorical import RhetoricalAnalyzer
from .core.content import ContentAnalyzer
from .core.meta import MetaAnalyzer

__version__ = '1.0.0'
__all__ = [
    'GrandpaDetector',
    'StatisticalAnalyzer',
    'LinguisticAnalyzer',
    'RhetoricalAnalyzer',
    'ContentAnalyzer',
    'MetaAnalyzer'
]