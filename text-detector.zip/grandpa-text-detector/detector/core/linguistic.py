"""
Linguistic Analyzer - Complete implementation
Analyzes sentence structure, vocabulary diversity, transitions, and hedge words
"""

import re
import math
import numpy as np
from collections import Counter
from nltk.tokenize import sent_tokenize, word_tokenize
import nltk

# Download required NLTK data
try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    nltk.download('punkt')

class LinguisticAnalyzer:
    """
    Analyzes linguistic patterns to distinguish AI from human writing
    Focuses on sentence structure, vocabulary richness, and natural language patterns
    """
    
    def __init__(self):
        # AI overuses these transition phrases
        self.ai_transition_phrases = [
            'however', 'therefore', 'furthermore', 'moreover',
            'consequently', 'in addition', 'for example', 'in conclusion',
            'firstly', 'secondly', 'finally', 'thus', 'hence',
            'additionally', 'nevertheless', 'nonetheless', 'accordingly',
            'as a result', 'for this reason', 'in contrast', 'on the other hand'
        ]
        
        # Humans use these hedge words (AI avoids uncertainty)
        self.hedge_words = [
            'perhaps', 'maybe', 'possibly', 'probably', 'approximately',
            'i think', 'it seems', 'apparently', 'arguably', 'somewhat',
            'quite', 'relatively', 'fairly', 'rather', 'nearly',
            'almost', 'sometimes', 'occasionally', 'often', 'usually',
            'i believe', 'i feel', 'in my opinion', 'it appears',
            'to some extent', 'in some ways', 'more or less'
        ]
        
        # Complex sentence markers (humans use more complex structures)
        self.complex_markers = [
            'which', 'that', 'who', 'whom', 'whose',
            'although', 'even though', 'despite', 'whereas',
            'while', 'whereas', 'unless', 'until', 'provided that'
        ]
        
        # Sentence starters that humans use naturally
        self.human_sentence_starters = [
            'i', 'we', 'you', 'they', 'he', 'she',
            'actually', 'basically', 'honestly', 'frankly',
            'well', 'so', 'anyway', 'you know', 'i mean',
            'the thing is', 'the point is', 'what i mean is'
        ]
        
        # AI overuses these sentence starters
        self.ai_sentence_starters = [
            'in conclusion', 'furthermore', 'moreover', 'additionally',
            'consequently', 'therefore', 'thus', 'hence', 'accordingly',
            'it is important to', 'it should be noted', 'it is worth mentioning'
        ]
    
    def analyze(self, text: str) -> dict:
        """
        Complete linguistic analysis of text
        Returns dictionary with all linguistic metrics and scores
        """
        if not text or len(text.strip()) < 50:
            return {
                'sentence_structure': 50.0,
                'vocabulary_diversity': 50.0,
                'transition_usage': 50.0,
                'hedge_words': 50.0,
                'complex_sentences': 50.0,
                'sentence_starters': 50.0,
                'linguistic_score': 50.0
            }
        
        # Calculate all metrics
        sentence_structure_score = self.analyze_sentence_structure(text)
        vocabulary_score = self.analyze_vocabulary_diversity(text)
        transition_score = self.analyze_transition_usage(text)
        hedge_score = self.analyze_hedge_words(text)
        complex_score = self.analyze_complex_sentences(text)
        starter_score = self.analyze_sentence_starters(text)
        
        # Weighted linguistic score
        linguistic_score = (
            sentence_structure_score * 0.15 +
            vocabulary_score * 0.25 +
            transition_score * 0.15 +
            hedge_score * 0.20 +
            complex_score * 0.15 +
            starter_score * 0.10
        )
        
        return {
            'sentence_structure': round(sentence_structure_score, 2),
            'vocabulary_diversity': round(vocabulary_score, 2),
            'transition_usage': round(transition_score, 2),
            'hedge_words': round(hedge_score, 2),
            'complex_sentences': round(complex_score, 2),
            'sentence_starters': round(starter_score, 2),
            'linguistic_score': round(linguistic_score, 2),
            'details': self._get_detailed_analysis(text)
        }
    
    def _get_detailed_analysis(self, text: str) -> dict:
        """Get detailed linguistic metrics for reporting"""
        sentences = sent_tokenize(text)
        words = word_tokenize(text.lower())
        words = [w for w in words if w.isalnum()]
        
        return {
            'sentence_count': len(sentences),
            'word_count': len(words),
            'avg_sentence_length': round(len(words) / len(sentences), 2) if sentences else 0,
            'unique_words': len(set(words)),
            'type_token_ratio': round(len(set(words)) / len(words), 3) if words else 0
        }
    
    def analyze_sentence_structure(self, text: str) -> float:
        """
        Analyze sentence structure variation
        Humans use varied sentence structures, AI tends to be uniform
        """
        sentences = sent_tokenize(text)
        if len(sentences) < 3:
            return 50.0
        
        # Get sentence lengths (in words)
        lengths = [len(word_tokenize(s)) for s in sentences]
        
        if not lengths:
            return 50.0
        
        # Calculate multiple variation metrics
        mean_length = np.mean(lengths)
        std_length = np.std(lengths)
        
        if mean_length == 0:
            return 50.0
        
        # Coefficient of variation (primary metric)
        cv = std_length / mean_length
        
        # Check for patterns in length distribution
        # Humans have more varied distribution
        length_percentiles = np.percentile(lengths, [25, 50, 75])
        percentile_range = length_percentiles[2] - length_percentiles[0]
        
        # Check for very short and very long sentences
        very_short = sum(1 for l in lengths if l < 5)
        very_long = sum(1 for l in lengths if l > 25)
        extreme_ratio = (very_short + very_long) / len(lengths)
        
        # Score calculation
        if cv > 0.6:
            cv_score = 90  # Highly varied = human
        elif cv > 0.4:
            cv_score = 75  # Moderately varied
        elif cv > 0.3:
            cv_score = 60  # Slightly varied
        elif cv > 0.2:
            cv_score = 45  # Quite uniform
        else:
            cv_score = 30  # Very uniform = AI
        
        # Bonus for natural extreme sentences (humans use them)
        if extreme_ratio > 0.2:
            cv_score += 10
        
        return min(100, cv_score)
    
    def analyze_vocabulary_diversity(self, text: str) -> float:
        """
        Analyze vocabulary richness using multiple metrics
        Humans use more diverse vocabulary, AI tends to be repetitive
        """
        words = word_tokenize(text.lower())
        words = [w for w in words if w.isalnum()]
        
        if len(words) < 20:
            return 50.0
        
        # 1. Type-Token Ratio (TTR)
        unique_words = set(words)
        ttr = len(unique_words) / len(words)
        
        # 2. Corrected TTR for text length
        cttr = len(unique_words) / math.sqrt(2 * len(words))
        
        # 3. Hapax Legomena (words that appear only once)
        word_counts = Counter(words)
        hapax_count = sum(1 for count in word_counts.values() if count == 1)
        hapax_ratio = hapax_count / len(words)
        
        # 4. Brunet's Index (vocabulary richness measure)
        try:
            brunet = len(words) ** (len(unique_words) ** -0.17)
        except:
            brunet = 0
        
        # 5. Honoré's Statistic (measures vocabulary richness)
        try:
            if hapax_count > 0:
                v1 = hapax_count
                v = len(unique_words)
                N = len(words)
                honore = 100 * math.log(N) / (1 - (v1 / v))
            else:
                honore = 0
        except:
            honore = 0
        
        # Normalize and combine scores
        ttr_score = min(100, ttr * 150)
        cttr_score = min(100, cttr * 50)
        hapax_score = min(100, hapax_ratio * 300)
        
        # Brunet index: higher = richer vocabulary
        brunet_score = min(100, (brunet - 10) * 5) if brunet > 10 else 30
        
        # Honoré: higher = richer vocabulary
        honore_score = min(100, honore / 10) if honore > 0 else 30
        
        # Weighted combination
        vocabulary_score = (
            ttr_score * 0.20 +
            cttr_score * 0.20 +
            hapax_score * 0.25 +
            brunet_score * 0.15 +
            honore_score * 0.20
        )
        
        return round(vocabulary_score, 2)
    
    def analyze_transition_usage(self, text: str) -> float:
        """
        Analyze transition word usage
        AI overuses transitions, humans use them more naturally
        """
        text_lower = text.lower()
        sentences = sent_tokenize(text)
        
        if len(sentences) < 3:
            return 50.0
        
        # Count AI-style transitions
        ai_transition_count = 0
        for phrase in self.ai_transition_phrases:
            ai_transition_count += len(re.findall(r'\b' + phrase + r'\b', text_lower))
        
        # Calculate transitions per sentence
        transitions_per_sentence = ai_transition_count / len(sentences)
        
        # Check for transition clusters (multiple transitions close together)
        transition_positions = []
        for phrase in self.ai_transition_phrases:
            for match in re.finditer(r'\b' + phrase + r'\b', text_lower):
                transition_positions.append(match.start())
        
        # Calculate average distance between transitions
        if len(transition_positions) > 1:
            distances = np.diff(sorted(transition_positions))
            avg_distance = np.mean(distances) if len(distances) > 0 else float('inf')
            distance_score = min(100, avg_distance / 50)  # Longer distance = better
        else:
            distance_score = 80  # Few transitions is good
        
        # Score based on transition density
        if transitions_per_sentence > 1.0:
            density_score = 20  # Too many transitions = AI
        elif transitions_per_sentence > 0.7:
            density_score = 40
        elif transitions_per_sentence > 0.4:
            density_score = 60
        elif transitions_per_sentence > 0.2:
            density_score = 75
        elif transitions_per_sentence > 0.1:
            density_score = 85
        else:
            density_score = 95  # Very few transitions = human-like
        
        # Combine scores
        final_score = (density_score * 0.6 + distance_score * 0.4)
        
        return round(final_score, 2)
    
    def analyze_hedge_words(self, text: str) -> float:
        """
        Analyze hedge word usage
        Humans use hedge words (uncertainty), AI avoids them
        """
        text_lower = text.lower()
        words = word_tokenize(text_lower)
        words = [w for w in words if w.isalnum()]
        
        if len(words) < 20:
            return 50.0
        
        # Count hedge words
        hedge_count = 0
        hedge_phrases_found = []
        
        for hedge in self.hedge_words:
            if ' ' in hedge:  # Multi-word hedge
                count = len(re.findall(r'\b' + hedge + r'\b', text_lower))
                if count > 0:
                    hedge_count += count
                    hedge_phrases_found.append(hedge)
            else:  # Single word hedge
                count = len(re.findall(r'\b' + hedge + r'\b', text_lower))
                if count > 0:
                    hedge_count += count
                    hedge_phrases_found.append(hedge)
        
        # Calculate hedge density per 100 words
        hedge_density = (hedge_count / len(words)) * 100
        
        # Check for variety in hedge words
        unique_hedges = len(set(hedge_phrases_found))
        variety_score = min(100, (unique_hedges / 5) * 100) if unique_hedges > 0 else 0
        
        # Score based on hedge density
        if hedge_density < 0.2:
            density_score = 20  # Too few hedges = AI (overly confident)
        elif hedge_density < 0.5:
            density_score = 40
        elif hedge_density < 1.0:
            density_score = 60
        elif hedge_density < 2.0:
            density_score = 80  # Good human range
        elif hedge_density < 3.5:
            density_score = 90  # Perfect human range
        elif hedge_density < 5.0:
            density_score = 75  # A bit too many hedges
        else:
            density_score = 50  # Too many hedges (insecure writer)
        
        # Combine density and variety
        final_score = (density_score * 0.7 + variety_score * 0.3)
        
        return round(final_score, 2)
    
    def analyze_complex_sentences(self, text: str) -> float:
        """
        Analyze complex sentence usage
        Humans use more complex sentence structures
        """
        sentences = sent_tokenize(text)
        if len(sentences) < 3:
            return 50.0
        
        text_lower = text.lower()
        
        # Count complex markers
        complex_count = 0
        for marker in self.complex_markers:
            complex_count += len(re.findall(r'\b' + marker + r'\b', text_lower))
        
        # Count subordinating conjunctions
        subordinators = ['because', 'since', 'as', 'although', 'though', 'while',
                        'whereas', 'unless', 'until', 'if', 'even if', 'provided']
        
        subord_count = 0
        for sub in subordinators:
            subord_count += len(re.findall(r'\b' + sub + r'\b', text_lower))
        
        # Count commas (indicating complex structures)
        comma_count = text.count(',')
        
        # Calculate metrics
        complex_per_sentence = complex_count / len(sentences)
        subord_per_sentence = subord_count / len(sentences)
        commas_per_sentence = comma_count / len(sentences)
        
        # Score calculation
        complex_score = min(100, complex_per_sentence * 50)
        subord_score = min(100, subord_per_sentence * 40)
        comma_score = min(100, commas_per_sentence * 20)
        
        # Humans use moderate complexity
        if 0.5 <= complex_per_sentence <= 2.0:
            complex_score = 85
        elif 2.0 < complex_per_sentence <= 3.0:
            complex_score = 70
        
        if 0.3 <= subord_per_sentence <= 1.5:
            subord_score = 85
        elif 1.5 < subord_per_sentence <= 2.5:
            subord_score = 70
        
        # Combine scores
        final_score = (complex_score * 0.4 + subord_score * 0.35 + comma_score * 0.25)
        
        return round(final_score, 2)
    
    def analyze_sentence_starters(self, text: str) -> float:
        """
        Analyze sentence starters
        Humans use varied starters, AI often repeats patterns
        """
        sentences = sent_tokenize(text)
        if len(sentences) < 5:
            return 50.0
        
        # Extract first 2-3 words of each sentence
        starters = []
        for sent in sentences:
            words = sent.split()
            if len(words) >= 2:
                starter = ' '.join(words[:2]).lower().rstrip('.,!?;:')
                starters.append(starter)
            elif words:
                starter = words[0].lower().rstrip('.,!?;:')
                starters.append(starter)
        
        if not starters:
            return 50.0
        
        # Count unique starters
        unique_starters = len(set(starters))
        starter_variety = (unique_starters / len(starters)) * 100
        
        # Check for AI-style starters
        ai_starter_count = 0
        for starter in starters:
            if any(ai_start in starter for ai_start in self.ai_sentence_starters):
                ai_starter_count += 1
        
        ai_starter_ratio = ai_starter_count / len(starters)
        
        # Check for human-style starters
        human_starter_count = 0
        for starter in starters:
            first_word = starter.split()[0] if starter else ''
            if first_word in self.human_sentence_starters:
                human_starter_count += 1
        
        human_starter_ratio = human_starter_count / len(starters)
        
        # Score calculation
        variety_score = min(100, starter_variety)
        
        if ai_starter_ratio > 0.3:
            ai_score = 30  # Too many AI starters
        elif ai_starter_ratio > 0.15:
            ai_score = 50
        else:
            ai_score = 80
        
        if human_starter_ratio > 0.2:
            human_score = 85
        elif human_starter_ratio > 0.1:
            human_score = 70
        else:
            human_score = 50
        
        # Combine scores
        final_score = (variety_score * 0.4 + ai_score * 0.3 + human_score * 0.3)
        
        return round(final_score, 2)