"""
Statistical Analyzer - Complete implementation
Measures perplexity, burstiness, repetition, and statistical patterns
"""

import math
import numpy as np
from collections import Counter
import re
from typing import Dict, Any, List, Tuple

class StatisticalAnalyzer:
    """
    Analyzes statistical patterns in text to distinguish AI from human writing
    Uses multiple statistical measures for robust detection
    """
    
    def __init__(self):
        # Pre-computed word frequencies from large English corpus
        self.word_frequencies = self._load_word_frequencies()
        # Common function words (higher in human writing)
        self.function_words = set([
            'the', 'be', 'to', 'of', 'and', 'a', 'in', 'that', 'have', 'i',
            'it', 'for', 'not', 'on', 'with', 'he', 'as', 'you', 'do', 'at',
            'this', 'but', 'his', 'by', 'from', 'they', 'we', 'say', 'her',
            'she', 'or', 'an', 'will', 'my', 'one', 'all', 'would', 'there',
            'their', 'what', 'so', 'up', 'out', 'if', 'about', 'who', 'get',
            'which', 'go', 'me', 'when', 'make', 'can', 'like', 'time', 'no',
            'just', 'him', 'know', 'take', 'people', 'into', 'year', 'your',
            'good', 'some', 'could', 'them', 'see', 'other', 'than', 'then',
            'now', 'look', 'only', 'come', 'its', 'over', 'think', 'also',
            'back', 'after', 'use', 'two', 'how', 'our', 'work', 'first',
            'well', 'way', 'even', 'new', 'want', 'because', 'any', 'these',
            'give', 'day', 'most', 'us'
        ])
    
    def _load_word_frequencies(self) -> Dict[str, float]:
        """
        Load pre-computed word frequencies
        These are from the Brown corpus and other English sources
        """
        return {
            'the': 0.061, 'be': 0.042, 'to': 0.035, 'of': 0.034, 'and': 0.031,
            'a': 0.030, 'in': 0.028, 'that': 0.025, 'have': 0.021, 'i': 0.020,
            'it': 0.019, 'for': 0.018, 'not': 0.017, 'on': 0.016, 'with': 0.015,
            'he': 0.014, 'as': 0.013, 'you': 0.012, 'do': 0.011, 'at': 0.010,
            'this': 0.009, 'but': 0.009, 'his': 0.008, 'by': 0.008, 'from': 0.008,
            'they': 0.007, 'we': 0.007, 'say': 0.006, 'her': 0.006, 'she': 0.006,
            'or': 0.006, 'an': 0.005, 'will': 0.005, 'my': 0.005, 'one': 0.005,
            'all': 0.005, 'would': 0.005, 'there': 0.005, 'their': 0.005,
            'what': 0.004, 'so': 0.004, 'up': 0.004, 'out': 0.004, 'if': 0.004,
            'about': 0.004, 'who': 0.004, 'get': 0.004, 'which': 0.004, 'go': 0.004,
            'me': 0.004, 'when': 0.004, 'make': 0.004, 'can': 0.004, 'like': 0.003,
            'time': 0.003, 'no': 0.003, 'just': 0.003, 'him': 0.003, 'know': 0.003,
            'take': 0.003, 'people': 0.003, 'into': 0.003, 'year': 0.003,
            'your': 0.003, 'good': 0.003, 'some': 0.003, 'could': 0.003,
            'them': 0.003, 'see': 0.003, 'other': 0.003, 'than': 0.003,
            'then': 0.003, 'now': 0.003, 'look': 0.003, 'only': 0.003,
            'come': 0.003, 'its': 0.003, 'over': 0.003, 'think': 0.003,
            'also': 0.002, 'back': 0.002, 'after': 0.002, 'use': 0.002,
            'two': 0.002, 'how': 0.002, 'our': 0.002, 'work': 0.002,
            'first': 0.002, 'well': 0.002, 'way': 0.002, 'even': 0.002,
            'new': 0.002, 'want': 0.002, 'because': 0.002, 'any': 0.002,
            'these': 0.002, 'give': 0.002, 'day': 0.002, 'most': 0.002,
            'us': 0.002
        }
    
    def analyze(self, text: str) -> Dict[str, Any]:
        """
        Complete statistical analysis of text
        Returns dictionary with all statistical metrics and scores
        """
        if not text or len(text.strip()) < 50:
            return {
                'perplexity': 50.0,
                'burstiness': 50.0,
                'repetition': 50.0,
                'entropy': 50.0,
                'zipf_coefficient': 50.0,
                'function_word_ratio': 50.0,
                'statistical_score': 50.0
            }
        
        # Calculate all metrics
        perplexity_result = self.calculate_perplexity(text)
        burstiness_score = self.calculate_burstiness(text)
        repetition_score = self.calculate_repetition_index(text)
        entropy_score = self.calculate_entropy(text)
        zipf_score = self.calculate_zipf_coefficient(text)
        function_word_score = self.analyze_function_words(text)
        
        # Weighted statistical score
        statistical_score = (
            perplexity_result['adjusted_score'] * 0.25 +
            burstiness_score * 0.20 +
            repetition_score * 0.20 +
            entropy_score * 0.15 +
            zipf_score * 0.10 +
            function_word_score * 0.10
        )
        
        return {
            'perplexity': perplexity_result,
            'burstiness': burstiness_score,
            'repetition': repetition_score,
            'entropy': entropy_score,
            'zipf_coefficient': zipf_score,
            'function_word_ratio': function_word_score,
            'statistical_score': round(statistical_score, 2)
        }
    
    def calculate_perplexity(self, text: str) -> Dict[str, float]:
        """
        Calculate text perplexity using multiple methods
        Lower perplexity (<60) = More predictable = AI-like
        Higher perplexity (>80) = More varied = Human-like
        """
        words = text.lower().split()
        words = [re.sub(r'[^\w\s]', '', w) for w in words if w]
        
        if len(words) < 10:
            return {
                'raw_perplexity': 50.0,
                'adjusted_perplexity': 50.0,
                'unknown_word_ratio': 0,
                'score': 50.0,
                'adjusted_score': 50.0
            }
        
        # Method 1: Simple word probability perplexity
        word_counts = Counter(words)
        total_words = len(words)
        
        log_prob_sum = 0
        unknown_words = 0
        
        for word in words:
            # Use pre-computed frequency or estimate from document
            if word in self.word_frequencies:
                prob = self.word_frequencies[word]
            else:
                prob = word_counts[word] / total_words
                unknown_words += 1
            
            # Avoid log(0)
            prob = max(prob, 1e-10)
            log_prob_sum += math.log2(prob)
        
        avg_log_prob = log_prob_sum / total_words
        raw_perplexity = 2 ** (-avg_log_prob)
        
        # Method 2: N-gram based perplexity (better for detection)
        ngram_perplexities = []
        for n in [2, 3]:
            ngrams = []
            for i in range(len(words) - n + 1):
                ngram = ' '.join(words[i:i+n])
                ngrams.append(ngram)
            
            if ngrams:
                ngram_counts = Counter(ngrams)
                ngram_log_prob = 0
                for ngram in ngrams[:100]:  # Sample for efficiency
                    prob = ngram_counts[ngram] / len(ngrams)
                    prob = max(prob, 1e-10)
                    ngram_log_prob += math.log2(prob)
                
                avg_ngram_log_prob = ngram_log_prob / min(100, len(ngrams))
                ngram_perplexity = 2 ** (-avg_ngram_log_prob)
                ngram_perplexities.append(ngram_perplexity)
        
        # Combine methods
        if ngram_perplexities:
            adjusted_perplexity = (raw_perplexity + np.mean(ngram_perplexities)) / 2
        else:
            adjusted_perplexity = raw_perplexity
        
        # Adjust for unknown words (creative writing = more unknown words)
        unknown_ratio = (unknown_words / total_words) * 100
        
        # Human writing has more rare/creative words
        creativity_bonus = min(30, unknown_ratio * 3)
        final_perplexity = adjusted_perplexity * (1 + creativity_bonus / 100)
        
        # Normalize to 0-100 scale
        # Typical range: 30-200
        normalized_raw = min(100, max(0, (raw_perplexity - 30) / 1.7))
        normalized_final = min(100, max(0, (final_perplexity - 30) / 1.7))
        
        return {
            'raw_perplexity': round(raw_perplexity, 2),
            'adjusted_perplexity': round(adjusted_perplexity, 2),
            'final_perplexity': round(final_perplexity, 2),
            'unknown_word_ratio': round(unknown_ratio, 2),
            'score': round(normalized_raw, 2),
            'adjusted_score': round(normalized_final, 2)
        }
    
    def calculate_burstiness(self, text: str) -> float:
        """
        Measure sentence length variation (burstiness)
        Low burstiness = Uniform lengths = AI-like
        High burstiness = Varied lengths = Human-like
        """
        # Split into sentences (handling multiple punctuation)
        sentences = re.split(r'[.!?]+', text)
        sentences = [s.strip() for s in sentences if len(s.strip()) > 10]
        
        if len(sentences) < 3:
            return 50.0
        
        # Calculate sentence lengths (in words and characters)
        word_lengths = []
        char_lengths = []
        
        for sent in sentences:
            words = sent.split()
            word_lengths.append(len(words))
            char_lengths.append(len(sent))
        
        # Coefficient of variation for word lengths
        word_mean = np.mean(word_lengths)
        word_std = np.std(word_lengths)
        word_cv = (word_std / word_mean) * 100 if word_mean > 0 else 0
        
        # Coefficient of variation for character lengths
        char_mean = np.mean(char_lengths)
        char_std = np.std(char_lengths)
        char_cv = (char_std / char_mean) * 100 if char_mean > 0 else 0
        
        # Combine both measures
        burstiness = (word_cv + char_cv) / 2
        
        # Calculate additional metrics
        # Check for patterns in sentence lengths (AI often has peaks)
        length_changes = []
        for i in range(1, len(word_lengths)):
            change = abs(word_lengths[i] - word_lengths[i-1])
            length_changes.append(change)
        
        avg_change = np.mean(length_changes) if length_changes else 0
        change_cv = np.std(length_changes) / avg_change if avg_change > 0 else 0
        
        # Human writing has more varied changes
        if change_cv > 0.8:
            burstiness *= 1.2  # Bonus for varied transitions
        
        # Normalize: typical human range 40-120
        normalized = min(100, max(0, burstiness))
        
        return round(normalized, 2)
    
    def calculate_repetition_index(self, text: str) -> float:
        """
        Detect repetitive patterns at multiple levels
        High repetition = AI-like
        Low repetition = Human-like
        """
        words = text.lower().split()
        words = [re.sub(r'[^\w]', '', w) for w in words if w]
        
        if len(words) < 20:
            return 50.0
        
        # Level 1: Word-level repetition
        unique_words = len(set(words))
        word_repetition = 100 - (unique_words / len(words) * 100)
        
        # Level 2: Phrase-level repetition (2-grams, 3-grams)
        phrase_repetition_scores = []
        
        for n in [2, 3, 4]:
            ngrams = []
            for i in range(len(words) - n + 1):
                ngram = ' '.join(words[i:i+n])
                ngrams.append(ngram)
            
            if ngrams:
                unique_ngrams = len(set(ngrams))
                repetition = 100 - (unique_ngrams / len(ngrams) * 100)
                phrase_repetition_scores.append(repetition)
        
        avg_phrase_repetition = np.mean(phrase_repetition_scores) if phrase_repetition_scores else 0
        
        # Level 3: Sentence structure repetition
        sentences = re.split(r'[.!?]+', text)
        sentences = [s.strip() for s in sentences if s.strip()]
        
        structure_repetition = 0
        if len(sentences) >= 3:
            # Check for repeated sentence openings
            openings = []
            for sent in sentences[:10]:  # First 10 sentences
                first_words = ' '.join(sent.split()[:2]).lower()
                openings.append(first_words)
            
            unique_openings = len(set(openings))
            if openings:
                structure_repetition = 100 - (unique_openings / len(openings) * 100)
        
        # Weighted combination
        total_repetition = (
            word_repetition * 0.3 +
            avg_phrase_repetition * 0.5 +
            structure_repetition * 0.2
        )
        
        # Convert to human score (inverse of repetition)
        human_score = 100 - total_repetition
        
        # Adjust for natural repetition in longer texts
        if len(words) > 500:
            human_score *= 1.1  # Bonus for maintaining variety in long texts
        
        return round(min(100, max(0, human_score)), 2)
    
    def calculate_entropy(self, text: str) -> float:
        """
        Calculate Shannon entropy of text
        Lower entropy = more predictable = AI-like
        Higher entropy = more random = Human-like
        """
        if not text:
            return 0
        
        # Character-level entropy
        char_counts = Counter(text)
        total_chars = len(text)
        
        char_entropy = 0
        for count in char_counts.values():
            probability = count / total_chars
            char_entropy -= probability * math.log2(probability)
        
        # Word-level entropy
        words = text.split()
        if words:
            word_counts = Counter(words)
            total_words = len(words)
            
            word_entropy = 0
            for count in word_counts.values():
                probability = count / total_words
                word_entropy -= probability * math.log2(probability)
        else:
            word_entropy = char_entropy
        
        # Combine entropies
        combined_entropy = (char_entropy + word_entropy) / 2
        
        # Normalize to 0-100 scale
        # Typical range: 4-8 for English text
        normalized = min(100, max(0, (combined_entropy - 4) * 25))
        
        return round(normalized, 2)
    
    def calculate_zipf_coefficient(self, text: str) -> float:
        """
        Calculate Zipf's law coefficient
        Human writing typically follows Zipf's law more closely
        """
        words = text.lower().split()
        words = [re.sub(r'[^\w]', '', w) for w in words if w]
        
        if len(words) < 50:
            return 50.0
        
        # Get word frequencies
        word_counts = Counter(words)
        frequencies = sorted(word_counts.values(), reverse=True)
        
        if len(frequencies) < 2:
            return 50.0
        
        # Calculate Zipf coefficient using log-log regression
        ranks = list(range(1, len(frequencies) + 1))
        log_ranks = [math.log(r) for r in ranks[:100]]  # Use top 100
        log_freqs = [math.log(f) for f in frequencies[:100]]
        
        # Simple linear regression
        n = len(log_ranks)
        if n < 2:
            return 50.0
        
        sum_x = sum(log_ranks)
        sum_y = sum(log_freqs)
        sum_xy = sum(x * y for x, y in zip(log_ranks, log_freqs))
        sum_xx = sum(x * x for x in log_ranks)
        
        try:
            slope = (n * sum_xy - sum_x * sum_y) / (n * sum_xx - sum_x * sum_x)
        except ZeroDivisionError:
            return 50.0
        
        # Ideal Zipf coefficient is around -1
        # Score based on how close slope is to -1
        ideal_slope = -1.0
        slope_diff = abs(slope - ideal_slope)
        
        if slope_diff < 0.1:
            return 90.0  # Perfect Zipf = human-like
        elif slope_diff < 0.2:
            return 75.0
        elif slope_diff < 0.3:
            return 60.0
        elif slope_diff < 0.5:
            return 45.0
        else:
            return 30.0  # Poor Zipf = AI-like
    
    def analyze_function_words(self, text: str) -> float:
        """
        Analyze function word usage
        Humans use more function words naturally
        """
        words = text.lower().split()
        words = [re.sub(r'[^\w]', '', w) for w in words if w]
        
        if len(words) < 20:
            return 50.0
        
        # Count function words
        function_word_count = sum(1 for w in words if w in self.function_words)
        function_word_ratio = (function_word_count / len(words)) * 100
        
        # Expected ratio in human writing: 40-60%
        if 45 <= function_word_ratio <= 55:
            return 90.0  # Perfect human range
        elif 40 <= function_word_ratio <= 60:
            return 80.0  # Good human range
        elif 35 <= function_word_ratio <= 65:
            return 65.0  # Acceptable
        elif 30 <= function_word_ratio <= 70:
            return 50.0  # Borderline
        else:
            return 30.0  # AI-like (too few or too many function words)