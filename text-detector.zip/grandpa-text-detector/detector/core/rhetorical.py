# Fix the rhetorical.py file with proper imports
"""
Rhetorical Analyzer - Complete implementation
Analyzes argument structure, personal voice, tone consistency, and rhetorical devices
"""

import re
import math
import numpy as np
from collections import Counter
from nltk.tokenize import sent_tokenize, word_tokenize
import nltk

# Download required NLTK data
try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    nltk.download('punkt')

class RhetoricalAnalyzer:
    """
    Analyzes rhetorical patterns to distinguish AI from human writing
    Focuses on argumentation, personal voice, and rhetorical devices
    """
    
    def __init__(self):
        # Personal pronouns (humans use them, AI avoids them)
        self.personal_pronouns = {
            'first_person_singular': ['i', 'me', 'my', 'mine', 'myself'],
            'first_person_plural': ['we', 'us', 'our', 'ours', 'ourselves'],
            'second_person': ['you', 'your', 'yours', 'yourself', 'yourselves'],
            'third_person': ['he', 'him', 'his', 'himself', 'she', 'her', 'hers', 'herself',
                            'it', 'its', 'itself', 'they', 'them', 'their', 'theirs', 'themselves']
        }
        
        # Opinion markers (humans express opinions)
        self.opinion_markers = [
            'i believe', 'in my opinion', 'i think', 'i feel', 'i consider',
            'from my perspective', 'it seems to me', 'i would argue',
            'i am convinced', 'i am certain', 'i doubt', 'i suspect',
            'to me', 'personally', 'in my view', 'as far as i\'m concerned',
            'if you ask me', 'the way i see it', 'i maintain that'
        ]
        
        # Argument structure markers
        self.claim_markers = [
            'because', 'since', 'as', 'due to', 'therefore', 'thus',
            'hence', 'consequently', 'so', 'accordingly', 'for this reason'
        ]
        
        self.evidence_markers = [
            'for example', 'for instance', 'such as', 'specifically',
            'in particular', 'to illustrate', 'as evidence', 'as shown by',
            'according to', 'based on', 'research shows', 'studies indicate'
        ]
        
        self.conclusion_markers = [
            'in conclusion', 'to conclude', 'in summary', 'to summarize',
            'overall', 'ultimately', 'finally', 'in the end', 'all things considered'
        ]
        
        # Rhetorical questions (humans use them, AI rarely does)
        self.rhetorical_question_indicators = [
            '?',  # Question mark
            'who would', 'what if', 'why would', 'how could',
            'isn\'t it', 'aren\'t we', 'wouldn\'t you'
        ]
        
        # Emotional language (humans use more emotion)
        self.emotional_words = {
            'positive': [
                'amazing', 'wonderful', 'excellent', 'fantastic', 'great',
                'love', 'happy', 'glad', 'pleased', 'delighted',
                'inspiring', 'encouraging', 'hopeful', 'optimistic'
            ],
            'negative': [
                'terrible', 'awful', 'horrible', 'dreadful', 'awful',
                'hate', 'angry', 'frustrated', 'disappointed', 'upset',
                'worried', 'concerned', 'anxious', 'fearful'
            ]
        }
        
        # Storytelling elements (humans tell stories)
        self.storytelling_markers = [
            'when i', 'i remember', 'i recall', 'back then',
            'one time', 'once upon a time', 'there was a time',
            'i experienced', 'i went through', 'i encountered',
            'it happened', 'the first time', 'after that'
        ]
        
        # Humor and irony markers (humans use humor)
        self.humor_markers = [
            'funny', 'hilarious', 'ironically', 'surprisingly',
            'unexpectedly', 'of course', 'needless to say',
            'believe it or not', 'wouldn\'t you know'
        ]
    
    def analyze(self, text: str) -> dict:
        """
        Complete rhetorical analysis of text
        Returns dictionary with all rhetorical metrics and scores
        """
        if not text or len(text.strip()) < 50:
            return {
                'personal_voice': 50.0,
                'argument_structure': 50.0,
                'tone_consistency': 50.0,
                'emotional_language': 50.0,
                'storytelling': 50.0,
                'rhetorical_questions': 50.0,
                'rhetorical_score': 50.0
            }
        
        # Calculate all metrics
        personal_voice_score = self.analyze_personal_voice(text)
        argument_score = self.analyze_argument_structure(text)
        tone_score = self.analyze_tone_consistency(text)
        emotional_score = self.analyze_emotional_language(text)
        storytelling_score = self.analyze_storytelling(text)
        questions_score = self.analyze_rhetorical_questions(text)
        
        # Weighted rhetorical score
        rhetorical_score = (
            personal_voice_score * 0.25 +
            argument_score * 0.20 +
            tone_score * 0.15 +
            emotional_score * 0.15 +
            storytelling_score * 0.15 +
            questions_score * 0.10
        )
        
        return {
            'personal_voice': round(personal_voice_score, 2),
            'argument_structure': round(argument_score, 2),
            'tone_consistency': round(tone_score, 2),
            'emotional_language': round(emotional_score, 2),
            'storytelling': round(storytelling_score, 2),
            'rhetorical_questions': round(questions_score, 2),
            'rhetorical_score': round(rhetorical_score, 2),
            'details': self._get_detailed_analysis(text)
        }
    
    def _get_detailed_analysis(self, text: str) -> dict:
        """Get detailed rhetorical metrics for reporting"""
        sentences = sent_tokenize(text)
        
        # Count personal pronouns
        pronoun_counts = {}
        text_lower = text.lower()
        
        for category, pronouns in self.personal_pronouns.items():
            count = 0
            for pronoun in pronouns:
                count += len(re.findall(r'\b' + pronoun + r'\b', text_lower))
            pronoun_counts[category] = count
        
        # Count questions
        question_count = text.count('?')
        
        # Count emotional words
        emotional_count = 0
        for category, words in self.emotional_words.items():
            for word in words:
                emotional_count += len(re.findall(r'\b' + word + r'\b', text_lower))
        
        return {
            'sentence_count': len(sentences),
            'personal_pronouns': pronoun_counts,
            'question_count': question_count,
            'emotional_word_count': emotional_count,
            'has_storytelling': any(marker in text_lower for marker in self.storytelling_markers)
        }
    
    def analyze_personal_voice(self, text: str) -> float:
        """
        Analyze personal voice and subjectivity
        Humans use personal voice, AI tends to be objective
        """
        text_lower = text.lower()
        words = word_tokenize(text_lower)
        words = [w for w in words if w.isalnum()]
        
        if len(words) < 20:
            return 50.0
        
        # Count personal pronouns by category
        pronoun_scores = {}
        total_pronouns = 0
        
        for category, pronouns in self.personal_pronouns.items():
            category_count = 0
            for pronoun in pronouns:
                count = len(re.findall(r'\b' + pronoun + r'\b', text_lower))
                category_count += count
                total_pronouns += count
            
            # Different weights for different pronoun types
            if category == 'first_person_singular':
                pronoun_scores[category] = category_count * 2.0  # Most personal
            elif category == 'first_person_plural':
                pronoun_scores[category] = category_count * 1.5  # Collective personal
            elif category == 'second_person':
                pronoun_scores[category] = category_count * 1.2  # Engaging reader
            else:  # third_person
                pronoun_scores[category] = category_count * 0.5  # Less personal
        
        # Count opinion markers
        opinion_count = 0
        for marker in self.opinion_markers:
            opinion_count += len(re.findall(r'\b' + marker + r'\b', text_lower))
        
        # Calculate pronoun density per 100 words
        pronoun_density = (total_pronouns / len(words)) * 100
        
        # Calculate weighted pronoun score
        weighted_pronoun_score = sum(pronoun_scores.values())
        weighted_density = (weighted_pronoun_score / len(words)) * 100
        
        # Opinion density
        opinion_density = (opinion_count / len(words)) * 100
        
        # Score calculation
        if 3 <= pronoun_density <= 8:
            density_score = 85  # Good human range
        elif 1 <= pronoun_density < 3:
            density_score = 70  # Somewhat reserved
        elif 8 < pronoun_density <= 12:
            density_score = 75  # A bit too personal
        elif pronoun_density > 12:
            density_score = 60  # Overly personal (maybe informal)
        else:
            density_score = 30  # Too few pronouns = AI-like
        
        # Weighted density gives bonus for first-person usage
        if weighted_density > pronoun_density * 1.2:
            weighted_bonus = 10
        else:
            weighted_bonus = 0
        
        # Opinion score
        if opinion_density > 1.0:
            opinion_score = 85
        elif opinion_density > 0.5:
            opinion_score = 75
        elif opinion_density > 0.2:
            opinion_score = 65
        elif opinion_density > 0.1:
            opinion_score = 55
        else:
            opinion_score = 40
        
        # Combine scores
        final_score = (density_score * 0.5 + opinion_score * 0.4 + weighted_bonus)
        
        return round(min(100, final_score), 2)
    
    def analyze_argument_structure(self, text: str) -> float:
        """
        Analyze how arguments are structured
        Humans have more natural argument flow, AI follows rigid patterns
        """
        sentences = sent_tokenize(text)
        if len(sentences) < 5:
            return 50.0
        
        text_lower = text.lower()
        
        # Count different argument elements
        claim_count = 0
        for marker in self.claim_markers:
            claim_count += len(re.findall(r'\b' + marker + r'\b', text_lower))
        
        evidence_count = 0
        for marker in self.evidence_markers:
            evidence_count += len(re.findall(r'\b' + marker + r'\b', text_lower))
        
        conclusion_count = 0
        for marker in self.conclusion_markers:
            conclusion_count += len(re.findall(r'\b' + marker + r'\b', text_lower))
        
        # Calculate ratios
        claim_ratio = claim_count / len(sentences)
        evidence_ratio = evidence_count / len(sentences)
        conclusion_ratio = conclusion_count / len(sentences)
        
        # Check for natural balance
        # Humans have moderate claims with good evidence
        if 0.2 <= claim_ratio <= 0.5:
            claim_score = 85
        elif 0.1 <= claim_ratio < 0.2:
            claim_score = 70
        elif 0.5 < claim_ratio <= 0.8:
            claim_score = 60
        else:
            claim_score = 40
        
        if evidence_ratio >= 0.15:
            evidence_score = 85  # Good evidence
        elif evidence_ratio >= 0.1:
            evidence_score = 75
        elif evidence_ratio >= 0.05:
            evidence_score = 60
        else:
            evidence_score = 30  # No evidence = AI-like
        
        # Check claim-evidence ratio (should be balanced)
        if claim_count > 0:
            claim_evidence_ratio = evidence_count / claim_count
            if 0.3 <= claim_evidence_ratio <= 0.8:
                balance_score = 90  # Well-balanced
            elif 0.2 <= claim_evidence_ratio < 0.3:
                balance_score = 75  # Slightly light on evidence
            elif 0.8 < claim_evidence_ratio <= 1.2:
                balance_score = 70  # Heavy on evidence
            else:
                balance_score = 50  # Poor balance
        else:
            balance_score = 40  # No claims
        
        # Check conclusion placement (should be near end)
        if conclusion_count > 0 and len(sentences) > 3:
            # Find conclusion markers positions
            conclusion_positions = []
            for i, sent in enumerate(sentences):
                if any(marker in sent.lower() for marker in self.conclusion_markers):
                    conclusion_positions.append(i)
            
            if conclusion_positions:
                avg_position = np.mean(conclusion_positions) / len(sentences)
                if avg_position > 0.7:
                    position_score = 85  # Good (near end)
                elif avg_position > 0.5:
                    position_score = 70  # Middle
                else:
                    position_score = 50  # Too early
            else:
                position_score = 60  # No explicit conclusion
        else:
            position_score = 60
        
        # Combine scores
        argument_score = (
            claim_score * 0.25 +
            evidence_score * 0.30 +
            balance_score * 0.30 +
            position_score * 0.15
        )
        
        return round(argument_score, 2)
    
    def analyze_tone_consistency(self, text: str) -> float:
        """
        Analyze tone consistency
        Humans have natural variation, AI is too perfectly consistent
        """
        sentences = sent_tokenize(text)
        if len(sentences) < 5:
            return 50.0
        
        # Analyze sentence openings
        openings = []
        for sent in sentences:
            words = sent.split()
            if words:
                # Get first 2 words as opening signature
                if len(words) >= 2:
                    opening = ' '.join(words[:2]).lower().rstrip('.,!?;:')
                else:
                    opening = words[0].lower().rstrip('.,!?;:')
                openings.append(opening)
        
        # Calculate opening variety
        unique_openings = len(set(openings))
        variety_score = (unique_openings / len(openings)) * 100 if openings else 0
        
        # Check for repeated opening patterns
        opening_counts = Counter(openings)
        repeated_openings = sum(1 for count in opening_counts.values() if count > 1)
        repetition_penalty = (repeated_openings / len(openings)) * 50 if openings else 0
        
        # Analyze sentence length progression
        lengths = [len(sent.split()) for sent in sentences]
        
        # Calculate smoothness of length changes
        length_changes = []
        for i in range(1, len(lengths)):
            change = abs(lengths[i] - lengths[i-1])
            length_changes.append(change)
        
        avg_change = np.mean(length_changes) if length_changes else 0
        change_std = np.std(length_changes) if length_changes else 0
        
        # Humans have varied changes, AI has uniform changes
        if change_std < 2 and avg_change < 3:
            change_score = 30  # Too uniform = AI
        elif change_std < 3 and avg_change < 4:
            change_score = 50
        elif change_std < 4 and avg_change < 5:
            change_score = 70
        elif change_std < 6:
            change_score = 85  # Good variation
        else:
            change_score = 75  # Very varied
        
        # Analyze tone words consistency
        positive_count = 0
        negative_count = 0
        text_lower = text.lower()
        
        for word in self.emotional_words['positive']:
            positive_count += len(re.findall(r'\b' + word + r'\b', text_lower))
        
        for word in self.emotional_words['negative']:
            negative_count += len(re.findall(r'\b' + word + r'\b', text_lower))
        
        total_emotional = positive_count + negative_count
        
        if total_emotional > 0:
            # Check for emotional balance (not too extreme)
            positive_ratio = positive_count / total_emotional
            
            if 0.4 <= positive_ratio <= 0.6:
                emotional_score = 85  # Well-balanced
            elif 0.3 <= positive_ratio <= 0.7:
                emotional_score = 75
            elif 0.2 <= positive_ratio <= 0.8:
                emotional_score = 60
            else:
                emotional_score = 45  # Too extreme
        else:
            emotional_score = 50  # No emotional content
        
        # Combine scores
        tone_score = (
            variety_score * 0.25 +
            (100 - repetition_penalty) * 0.25 +
            change_score * 0.25 +
            emotional_score * 0.25
        )
        
        return round(min(100, tone_score), 2)
    
    def analyze_emotional_language(self, text: str) -> float:
        """
        Analyze use of emotional language
        Humans use more emotional words, AI is more neutral
        """
        text_lower = text.lower()
        words = word_tokenize(text_lower)
        words = [w for w in words if w.isalnum()]
        
        if len(words) < 20:
            return 50.0
        
        # Count positive emotional words
        positive_count = 0
        positive_words_found = []
        for word in self.emotional_words['positive']:
            count = len(re.findall(r'\b' + word + r'\b', text_lower))
            if count > 0:
                positive_count += count
                positive_words_found.append(word)
        
        # Count negative emotional words
        negative_count = 0
        negative_words_found = []
        for word in self.emotional_words['negative']:
            count = len(re.findall(r'\b' + word + r'\b', text_lower))
            if count > 0:
                negative_count += count
                negative_words_found.append(word)
        
        total_emotional = positive_count + negative_count
        emotional_density = (total_emotional / len(words)) * 100
        
        # Check variety of emotional words
        unique_emotional = len(set(positive_words_found + negative_words_found))
        variety_score = min(100, (unique_emotional / 5) * 100)
        
        # Score based on density
        if emotional_density > 3.0:
            density_score = 85  # Rich emotional content
        elif emotional_density > 2.0:
            density_score = 80
        elif emotional_density > 1.0:
            density_score = 70
        elif emotional_density > 0.5:
            density_score = 60
        elif emotional_density > 0.2:
            density_score = 50
        else:
            density_score = 30  # Too neutral = AI-like
        
        # Bonus for emotional balance (both positive and negative)
        if positive_count > 0 and negative_count > 0:
            balance_bonus = 10
            # Check if balanced
            total = positive_count + negative_count
            pos_ratio = positive_count / total
            if 0.3 <= pos_ratio <= 0.7:
                balance_bonus += 5
        else:
            balance_bonus = 0
        
        final_score = (density_score * 0.6 + variety_score * 0.3 + balance_bonus)
        
        return round(min(100, final_score), 2)
    
    def analyze_storytelling(self, text: str) -> float:
        """
        Analyze storytelling elements
        Humans use narratives and personal stories, AI rarely does
        """
        text_lower = text.lower()
        sentences = sent_tokenize(text)
        
        if len(sentences) < 5:
            return 50.0
        
        # Count storytelling markers
        storytelling_count = 0
        markers_found = []
        
        for marker in self.storytelling_markers:
            count = len(re.findall(r'\b' + marker + r'\b', text_lower))
            if count > 0:
                storytelling_count += count
                markers_found.append(marker)
        
        # Look for temporal progression (stories have time markers)
        time_markers = ['first', 'then', 'next', 'after', 'later', 'finally',
                       'before', 'during', 'while', 'when', 'afterwards']
        
        time_count = 0
        for marker in time_markers:
            time_count += len(re.findall(r'\b' + marker + r'\b', text_lower))
        
        # Look for personal experiences
        experience_markers = ['i experienced', 'i went', 'i saw', 'i heard',
                             'i felt', 'i noticed', 'i encountered']
        
        experience_count = 0
        for marker in experience_markers:
            experience_count += len(re.findall(r'\b' + marker + r'\b', text_lower))
        
        # Calculate storytelling density
        storytelling_density = (storytelling_count / len(sentences)) * 10
        time_density = (time_count / len(sentences)) * 5
        experience_density = (experience_count / len(sentences)) * 15
        
        # Score calculation
        if storytelling_density > 2.0:
            story_score = 90  # Strong storytelling
        elif storytelling_density > 1.0:
            story_score = 80
        elif storytelling_density > 0.5:
            story_score = 70
        elif storytelling_density > 0.2:
            story_score = 60
        elif storytelling_density > 0:
            story_score = 50
        else:
            story_score = 30  # No storytelling = AI-like
        
        # Add bonuses
        if experience_count > 0:
            story_score += 10
        if time_count > 3:
            story_score += 5
        
        return round(min(100, story_score), 2)
    
    def analyze_rhetorical_questions(self, text: str) -> float:
        """
        Analyze use of rhetorical questions
        Humans use rhetorical questions, AI rarely does
        """
        # Count questions
        question_count = text.count('?')
        
        sentences = sent_tokenize(text)
        if len(sentences) < 3:
            return 50.0
        
        # Identify rhetorical questions (not just any question)
        rhetorical_count = 0
        rhetorical_indicators = [
            'who would', 'what if', 'why would', 'how could',
            'isn\'t it', 'aren\'t we', 'wouldn\'t you',
            'don\'t you', 'can\'t we', 'could it be'
        ]
        
        text_lower = text.lower()
        for indicator in rhetorical_indicators:
            rhetorical_count += len(re.findall(r'\b' + indicator + r'\b', text_lower))
        
        # Count total questions (with question marks)
        question_mark_count = text.count('?')
        
        # Calculate question density
        question_density = (question_mark_count / len(sentences)) * 10
        
        # Score calculation
        if question_density > 2.0:
            question_score = 85  # Good use of questions
        elif question_density > 1.0:
            question_score = 80
        elif question_density > 0.5:
            question_score = 70
        elif question_density > 0.2:
            question_score = 60
        elif question_density > 0:
            question_score = 50
        else:
            question_score = 30  # No questions = AI-like
        
        # Bonus for rhetorical questions
        if rhetorical_count > 0:
            question_score += 10
        
        # Check if questions are varied (not just repeated pattern)
        if rhetorical_count > 1:
            question_score += 5
        
        return round(min(100, question_score), 2)
