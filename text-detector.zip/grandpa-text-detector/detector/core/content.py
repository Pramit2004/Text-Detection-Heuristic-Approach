"""
Content Analyzer - Complete implementation
Analyzes content specificity, examples, authenticity, and factual density
"""

import re
import math
import numpy as np
from collections import Counter
from typing import Dict, Any, List, Tuple
import spacy
import subprocess
import sys

# Load spaCy model with error handling
try:
    nlp = spacy.load("en_core_web_sm")
except OSError:
    # If model not found, download it
    print("Downloading spaCy model...")
    subprocess.run([sys.executable, "-m", "spacy", "download", "en_core_web_sm"])
    nlp = spacy.load("en_core_web_sm")

class ContentAnalyzer:
    """
    Analyzes content patterns to distinguish AI from human writing
    Focuses on specificity, examples, authenticity, and factual content
    """
    
    def __init__(self):
        # Generic phrases that AI overuses
        self.generic_phrases = [
            'hardworking', 'dedicated', 'team player', 'excellent communication',
            'detail-oriented', 'results-driven', 'think outside the box',
            'synergy', 'leverage', 'optimize', 'streamline', 'innovative',
            'dynamic', 'proactive', 'passionate', 'motivated', 'enthusiastic',
            'strategic', 'collaborative', 'creative', 'analytical', 'adaptable',
            'in today\'s world', 'in today\'s society', 'in the modern era',
            'it is important to', 'it should be noted', 'it is worth mentioning',
            'as previously stated', 'as mentioned above', 'in the following sections'
        ]
        
        # Specific detail indicators (humans use these)
        self.specific_indicators = [
            r'\d+%', r'\d+ percent', r'\d+ years', r'\d+ months', r'\d+ days',
            r'\d+ people', r'\d+ employees', r'\d+ customers', r'\d+ users',
            r'\d+ million', r'\d+ billion', r'\d+ thousand',
            r'Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec',
            r'monday|tuesday|wednesday|thursday|friday|saturday|sunday',
            r'yesterday|today|tomorrow|last week|next week'
        ]
        
        # Personal experience markers
        self.personal_markers = [
            'i remember', 'i recall', 'i experienced', 'i witnessed',
            'i encountered', 'i faced', 'i dealt with', 'i handled',
            'i learned', 'i discovered', 'i realized', 'i noticed',
            'i felt', 'i thought', 'i believed', 'i considered',
            'in my experience', 'from my experience', 'based on my experience'
        ]
        
        # Anecdote markers (humans tell stories)
        self.anecdote_markers = [
            'one time', 'once when', 'there was a time', 'back when',
            'when i was', 'during my', 'while working on', 'while at',
            'it happened that', 'as it turned out', 'what happened was'
        ]
        
        # Concrete vs abstract word lists
        self.concrete_words = [
            'table', 'chair', 'computer', 'phone', 'book', 'car', 'house',
            'office', 'building', 'street', 'city', 'country', 'person',
            'manager', 'employee', 'customer', 'client', 'product', 'service',
            'meeting', 'call', 'email', 'report', 'document', 'file',
            'money', 'dollar', 'price', 'cost', 'budget', 'revenue', 'profit'
        ]
        
        self.abstract_words = [
            'idea', 'concept', 'theory', 'philosophy', 'principle',
            'belief', 'value', 'culture', 'vision', 'mission', 'strategy',
            'quality', 'excellence', 'innovation', 'creativity', 'passion',
            'success', 'achievement', 'goal', 'objective', 'target',
            'improvement', 'development', 'growth', 'progress', 'change'
        ]
        
        # Factual indicators
        self.factual_markers = [
            'according to', 'based on', 'research shows', 'studies indicate',
            'data suggests', 'statistics show', 'survey found', 'analysis reveals',
            'report states', 'article mentions', 'source confirms'
        ]
        
        # Uncertainty markers (humans express uncertainty)
        self.uncertainty_markers = [
            'maybe', 'perhaps', 'possibly', 'probably', 'likely',
            'unclear', 'uncertain', 'unsure', 'doubtful', 'questionable',
            'i think', 'i believe', 'i suspect', 'i assume', 'i guess',
            'it seems', 'it appears', 'it looks like', 'it might be'
        ]
        
        # Exaggeration markers (AI tends to exaggerate)
        self.exaggeration_markers = [
            'always', 'never', 'everyone', 'no one', 'all', 'none',
            'perfect', 'flawless', 'impossible', 'incredible', 'unbelievable',
            'best', 'worst', 'greatest', 'terrible', 'awful', 'amazing'
        ]
    
    def analyze(self, text: str) -> dict:
        """
        Complete content analysis of text
        Returns dictionary with all content metrics and scores
        """
        if not text or len(text.strip()) < 50:
            return {
                'specificity': 50.0,
                'examples': 50.0,
                'authenticity': 50.0,
                'factual_density': 50.0,
                'concrete_ratio': 50.0,
                'anecdotes': 50.0,
                'content_score': 50.0
            }
        
        # Calculate all metrics
        specificity_score = self.analyze_specificity(text)
        examples_score = self.analyze_examples(text)
        authenticity_score = self.analyze_authenticity(text)
        factual_score = self.analyze_factual_density(text)
        concrete_score = self.analyze_concrete_abstract_ratio(text)
        anecdote_score = self.analyze_anecdotes(text)
        
        # Weighted content score
        content_score = (
            specificity_score * 0.20 +
            examples_score * 0.20 +
            authenticity_score * 0.20 +
            factual_score * 0.15 +
            concrete_score * 0.15 +
            anecdote_score * 0.10
        )
        
        return {
            'specificity': round(specificity_score, 2),
            'examples': round(examples_score, 2),
            'authenticity': round(authenticity_score, 2),
            'factual_density': round(factual_score, 2),
            'concrete_ratio': round(concrete_score, 2),
            'anecdotes': round(anecdote_score, 2),
            'content_score': round(content_score, 2),
            'details': self._get_detailed_analysis(text)
        }
    
    def _get_detailed_analysis(self, text: str) -> dict:
        """Get detailed content metrics for reporting"""
        doc = nlp(text[:10000])  # Limit for performance
        
        # Extract entities
        entities = {}
        for ent in doc.ents:
            if ent.label_ not in entities:
                entities[ent.label_] = []
            if ent.text not in entities[ent.label_]:
                entities[ent.label_].append(ent.text)
        
        # Count numbers
        numbers = len([token for token in doc if token.like_num])
        
        # Count proper nouns
        proper_nouns = len([token for token in doc if token.pos_ == "PROPN"])
        
        return {
            'entity_count': len(doc.ents),
            'entity_types': {k: len(v) for k, v in entities.items()},
            'number_count': numbers,
            'proper_noun_count': proper_nouns,
            'entities_found': entities
        }
    
    def analyze_specificity(self, text: str) -> float:
        """
        Analyze how specific the content is
        Humans use specific details, AI tends to be generic
        """
        doc = nlp(text[:10000])  # Limit for performance
        
        # 1. Count specific numbers (dates, percentages, quantities)
        numbers = len([token for token in doc if token.like_num])
        
        # 2. Count proper nouns (specific names, places, organizations)
        proper_nouns = len([token for token in doc if token.pos_ == "PROPN"])
        
        # 3. Count named entities
        entities = len(doc.ents)
        
        # 4. Count specific quantifiers using regex
        text_lower = text.lower()
        specific_indicators_count = 0
        for pattern in self.specific_indicators:
            matches = re.findall(pattern, text_lower)
            specific_indicators_count += len(matches)
        
        # 5. Count concrete words vs generic words
        words = [token.text.lower() for token in doc if token.is_alpha]
        
        concrete_count = sum(1 for w in words if w in self.concrete_words)
        generic_phrase_count = 0
        for phrase in self.generic_phrases:
            generic_phrase_count += len(re.findall(r'\b' + phrase + r'\b', text_lower))
        
        # Calculate densities (per 100 words)
        word_count = len(words) if words else 1
        
        number_density = (numbers / word_count) * 100
        proper_noun_density = (proper_nouns / word_count) * 100
        entity_density = (entities / word_count) * 100
        specific_indicator_density = (specific_indicators_count / word_count) * 100
        concrete_density = (concrete_count / word_count) * 100
        generic_density = (generic_phrase_count / word_count) * 100
        
        # Score calculation
        # Numbers score
        if number_density > 3.0:
            number_score = 90
        elif number_density > 2.0:
            number_score = 80
        elif number_density > 1.0:
            number_score = 70
        elif number_density > 0.5:
            number_score = 60
        elif number_density > 0:
            number_score = 50
        else:
            number_score = 30
        
        # Proper noun score
        if proper_noun_density > 5.0:
            proper_score = 85
        elif proper_noun_density > 3.0:
            proper_score = 80
        elif proper_noun_density > 1.0:
            proper_score = 70
        elif proper_noun_density > 0.5:
            proper_score = 60
        elif proper_noun_density > 0:
            proper_score = 50
        else:
            proper_score = 30
        
        # Entity score
        if entity_density > 4.0:
            entity_score = 85
        elif entity_density > 2.0:
            entity_score = 75
        elif entity_density > 1.0:
            entity_score = 65
        elif entity_density > 0.5:
            entity_score = 55
        elif entity_density > 0:
            entity_score = 45
        else:
            entity_score = 30
        
        # Specific indicators score
        if specific_indicator_density > 2.0:
            indicator_score = 85
        elif specific_indicator_density > 1.0:
            indicator_score = 75
        elif specific_indicator_density > 0.5:
            indicator_score = 65
        elif specific_indicator_density > 0.2:
            indicator_score = 55
        elif specific_indicator_density > 0:
            indicator_score = 45
        else:
            indicator_score = 30
        
        # Generic phrase penalty
        generic_penalty = min(30, generic_density * 10)
        
        # Concrete/abstract balance
        if concrete_density > 2.0:
            concrete_score = 80
        else:
            concrete_score = 50
        
        # Combine scores
        specificity_score = (
            number_score * 0.20 +
            proper_score * 0.20 +
            entity_score * 0.15 +
            indicator_score * 0.25 +
            concrete_score * 0.20 -
            generic_penalty * 0.10
        )
        
        return round(max(0, min(100, specificity_score)), 2)
    
    def analyze_examples(self, text: str) -> float:
        """
        Analyze quality and relevance of examples
        Humans use personal, specific examples; AI uses generic ones
        """
        text_lower = text.lower()
        sentences = re.split(r'[.!?]+', text)
        sentences = [s.strip() for s in sentences if len(s.strip()) > 20]
        
        if len(sentences) < 3:
            return 50.0
        
        # Find example sentences
        example_markers = [
            r'for example', r'for instance', r'such as',
            r'e\.g\.', r'like when', r'one example', r'an example',
            r'to illustrate', r'as an illustration', r'case in point'
        ]
        
        examples_found = []
        example_sentences = []
        
        for i, sentence in enumerate(sentences):
            sent_lower = sentence.lower()
            for marker in example_markers:
                if re.search(marker, sent_lower):
                    examples_found.append({
                        'text': sentence,
                        'marker': marker,
                        'position': i
                    })
                    example_sentences.append(sentence)
                    break
        
        if not examples_found:
            return 40.0  # No examples = AI-like
        
        # Analyze each example for quality
        example_scores = []
        
        for example in examples_found:
            example_text = example['text'].lower()
            score = 50  # Base score
            
            # Check for personal elements
            if any(marker in example_text for marker in self.personal_markers):
                score += 20
            
            # Check for specific details
            if re.search(r'\d+', example_text):
                score += 15
            
            # Check for proper nouns (specific names, places)
            doc = nlp(example['text'][:500])
            if len(doc.ents) > 0:
                score += 15
            
            # Check for concrete details
            words = example_text.split()
            concrete_count = sum(1 for w in words if w in self.concrete_words)
            if concrete_count > 2:
                score += 10
            
            # Check for storytelling elements
            if any(marker in example_text for marker in self.anecdote_markers):
                score += 15
            
            # Penalize generic examples
            generic_indicators = ['something', 'someone', 'somewhere', 'thing', 'stuff']
            generic_count = sum(1 for g in generic_indicators if g in example_text)
            score -= generic_count * 5
            
            example_scores.append(min(100, score))
        
        # Calculate average example quality
        avg_example_score = np.mean(example_scores) if example_scores else 50
        
        # Check example variety (different types of examples)
        if len(examples_found) >= 2:
            # Check if examples use different markers
            markers_used = set(e['marker'] for e in examples_found)
            variety_bonus = min(15, len(markers_used) * 5)
            avg_example_score += variety_bonus
        
        # Check example placement (should be distributed)
        positions = [e['position'] for e in examples_found]
        if len(positions) > 1:
            position_std = np.std(positions) if len(positions) > 1 else 0
            if position_std > len(sentences) * 0.2:
                avg_example_score += 10  # Well-distributed examples
        
        return round(min(100, avg_example_score), 2)
    
    def analyze_authenticity(self, text: str) -> float:
        """
        Analyze authenticity and genuine human elements
        Detects genuine personal experiences, vulnerabilities, and authentic voice
        """
        text_lower = text.lower()
        doc = nlp(text[:10000])
        
        # 1. Look for personal experiences
        personal_exp_count = 0
        for marker in self.personal_markers:
            personal_exp_count += len(re.findall(r'\b' + marker + r'\b', text_lower))
        
        # 2. Look for anecdotes (storytelling)
        anecdote_count = 0
        for marker in self.anecdote_markers:
            anecdote_count += len(re.findall(r'\b' + marker + r'\b', text_lower))
        
        # 3. Look for vulnerability (admitting challenges/failures)
        vulnerability_markers = [
            'struggled', 'challenged', 'difficult', 'hard', 'tough',
            'failed', 'mistake', 'error', 'problem', 'issue',
            'learned', 'grew', 'improved', 'developed', 'overcame',
            'didn\'t know', 'wasn\'t sure', 'was confused', 'was lost'
        ]
        
        vulnerability_count = 0
        for marker in vulnerability_markers:
            vulnerability_count += len(re.findall(r'\b' + marker + r'\b', text_lower))
        
        # 4. Look for genuine emotion (not just positive fluff)
        genuine_emotion_markers = [
            'felt', 'feeling', 'emotion', 'excited', 'nervous',
            'worried', 'anxious', 'scared', 'happy', 'sad',
            'angry', 'frustrated', 'disappointed', 'proud', 'grateful'
        ]
        
        emotion_count = 0
        for marker in genuine_emotion_markers:
            emotion_count += len(re.findall(r'\b' + marker + r'\b', text_lower))
        
        # 5. Look for uncertainty (honest admission of not knowing)
        uncertainty_count = 0
        for marker in self.uncertainty_markers:
            uncertainty_count += len(re.findall(r'\b' + marker + r'\b', text_lower))
        
        # 6. Check for exaggeration (less authentic)
        exaggeration_count = 0
        for marker in self.exaggeration_markers:
            exaggeration_count += len(re.findall(r'\b' + marker + r'\b', text_lower))
        
        # Calculate word count
        words = [token.text for token in doc if token.is_alpha]
        word_count = len(words) if words else 1
        
        # Calculate densities
        personal_density = (personal_exp_count / word_count) * 100
        anecdote_density = (anecdote_count / word_count) * 100
        vulnerability_density = (vulnerability_count / word_count) * 100
        emotion_density = (emotion_count / word_count) * 100
        uncertainty_density = (uncertainty_count / word_count) * 100
        exaggeration_density = (exaggeration_count / word_count) * 100
        
        # Score calculation
        authenticity_score = 50  # Base score
        
        # Add for genuine human elements
        if personal_density > 0.5:
            authenticity_score += 15
        elif personal_density > 0.2:
            authenticity_score += 10
        elif personal_density > 0:
            authenticity_score += 5
        
        if anecdote_density > 0.3:
            authenticity_score += 15
        elif anecdote_density > 0.1:
            authenticity_score += 10
        elif anecdote_density > 0:
            authenticity_score += 5
        
        if vulnerability_density > 0.2:
            authenticity_score += 20  # Strong authenticity indicator
        elif vulnerability_density > 0.1:
            authenticity_score += 15
        elif vulnerability_density > 0:
            authenticity_score += 8
        
        if emotion_density > 0.5:
            authenticity_score += 15
        elif emotion_density > 0.2:
            authenticity_score += 10
        elif emotion_density > 0:
            authenticity_score += 5
        
        if uncertainty_density > 0.3:
            authenticity_score += 15
        elif uncertainty_density > 0.1:
            authenticity_score += 10
        elif uncertainty_density > 0:
            authenticity_score += 5
        
        # Penalize exaggeration
        if exaggeration_density > 1.0:
            authenticity_score -= 20
        elif exaggeration_density > 0.5:
            authenticity_score -= 15
        elif exaggeration_density > 0.2:
            authenticity_score -= 10
        elif exaggeration_density > 0:
            authenticity_score -= 5
        
        # Check for first-person narrative (more authentic)
        first_person = ['i ', ' i\'', ' me ', ' my ', ' mine ']
        first_person_count = 0
        for fp in first_person:
            first_person_count += text_lower.count(fp)
        
        if first_person_count > 5:
            authenticity_score += 10
        elif first_person_count > 2:
            authenticity_score += 5
        
        # Check for specific, verifiable details
        if re.search(r'\b\d{4}\b', text):  # Years
            authenticity_score += 5
        if re.search(r'[A-Z][a-z]+ [A-Z][a-z]+', text):  # Proper names
            authenticity_score += 5
        
        return round(max(0, min(100, authenticity_score)), 2)
    
    def analyze_factual_density(self, text: str) -> float:
        """
        Analyze density of factual information
        Humans mix facts with opinions, AI can be overly factual or vague
        """
        doc = nlp(text[:10000])
        text_lower = text.lower()
        
        # Count factual markers
        factual_count = 0
        for marker in self.factual_markers:
            factual_count += len(re.findall(r'\b' + marker + r'\b', text_lower))
        
        # Count numbers (often indicate facts)
        numbers = len([token for token in doc if token.like_num])
        
        # Count entities (specific facts)
        entities = len(doc.ents)
        
        # Count dates (factual time references)
        dates = 0
        for ent in doc.ents:
            if ent.label_ == "DATE" or ent.label_ == "TIME":
                dates += 1
        
        # Count statistics indicators
        stats_indicators = ['%', 'percent', 'statistic', 'average', 'median',
                           'majority', 'minority', 'ratio', 'proportion']
        stats_count = 0
        for indicator in stats_indicators:
            stats_count += len(re.findall(r'\b' + indicator + r'\b', text_lower))
        
        # Calculate word count
        words = [token.text for token in doc if token.is_alpha]
        word_count = len(words) if words else 1
        
        # Calculate densities
        factual_density = (factual_count / word_count) * 100
        number_density = (numbers / word_count) * 100
        entity_density = (entities / word_count) * 100
        date_density = (dates / word_count) * 100
        stats_density = (stats_count / word_count) * 100
        
        # Score calculation
        factual_score = 50
        
        # Optimal factual density for human writing
        if 1.0 <= factual_density <= 3.0:
            factual_score += 15
        elif factual_density > 3.0:
            factual_score += 10  # Slightly too factual
        elif factual_density > 0.5:
            factual_score += 5
        else:
            factual_score -= 10  # Too few facts
        
        if 2.0 <= number_density <= 5.0:
            factual_score += 15
        elif number_density > 5.0:
            factual_score += 10
        elif number_density > 1.0:
            factual_score += 5
        elif number_density > 0:
            factual_score += 2
        else:
            factual_score -= 10
        
        if entity_density > 3.0:
            factual_score += 15
        elif entity_density > 1.5:
            factual_score += 10
        elif entity_density > 0.5:
            factual_score += 5
        elif entity_density > 0:
            factual_score += 2
        
        if date_density > 0.5:
            factual_score += 10
        
        if stats_density > 0.2:
            factual_score += 10
        
        # Check for fact vs opinion balance
        opinion_markers = ['i think', 'i believe', 'in my opinion', 'i feel']
        opinion_count = 0
        for marker in opinion_markers:
            opinion_count += len(re.findall(r'\b' + marker + r'\b', text_lower))
        
        opinion_density = (opinion_count / word_count) * 100
        
        # Good balance: both facts and opinions
        if 0.2 <= opinion_density <= 1.0 and factual_density > 0.5:
            factual_score += 10
        
        return round(max(0, min(100, factual_score)), 2)
    
    def analyze_concrete_abstract_ratio(self, text: str) -> float:
        """
        Analyze ratio of concrete to abstract words
        Humans use mix, AI tends to be overly abstract
        """
        doc = nlp(text[:10000])
        
        # Get words
        words = [token.text.lower() for token in doc if token.is_alpha]
        
        if len(words) < 20:
            return 50.0
        
        # Count concrete words
        concrete_count = sum(1 for w in words if w in self.concrete_words)
        
        # Count abstract words
        abstract_count = sum(1 for w in words if w in self.abstract_words)
        
        # Calculate ratio
        if abstract_count > 0:
            concrete_ratio = concrete_count / abstract_count
        else:
            concrete_ratio = concrete_count if concrete_count > 0 else 1
        
        # Score based on ratio
        # Humans use more concrete than abstract, but not excessively
        if 1.5 <= concrete_ratio <= 3.0:
            return 90  # Ideal balance
        elif 1.0 <= concrete_ratio < 1.5:
            return 80  # Good balance
        elif 3.0 < concrete_ratio <= 5.0:
            return 70  # Too concrete
        elif 0.5 <= concrete_ratio < 1.0:
            return 60  # Too abstract
        elif concrete_ratio > 5.0:
            return 50  # Extremely concrete
        elif concrete_ratio < 0.5:
            return 40  # Extremely abstract
        else:
            return 50
    
    def analyze_anecdotes(self, text: str) -> float:
        """
        Analyze presence and quality of anecdotes
        Humans use anecdotes, AI rarely does
        """
        text_lower = text.lower()
        
        # Look for anecdote markers
        anecdote_count = 0
        markers_found = []
        
        for marker in self.anecdote_markers:
            count = len(re.findall(r'\b' + marker + r'\b', text_lower))
            if count > 0:
                anecdote_count += count
                markers_found.append(marker)
        
        # Look for story structure
        story_elements = {
            'introduction': ['when', 'while', 'during', 'back in'],
            'development': ['then', 'next', 'after', 'later', 'subsequently'],
            'conclusion': ['finally', 'ultimately', 'in the end', 'eventually']
        }
        
        element_counts = {}
        for element, markers in story_elements.items():
            count = 0
            for marker in markers:
                count += len(re.findall(r'\b' + marker + r'\b', text_lower))
            element_counts[element] = count
        
        # Calculate anecdote density
        sentences = sent_tokenize(text)
        if sentences:
            anecdote_density = (anecdote_count / len(sentences)) * 10
        else:
            anecdote_density = 0
        
        # Score calculation
        if anecdote_density > 2.0:
            anecdote_score = 90
        elif anecdote_density > 1.0:
            anecdote_score = 80
        elif anecdote_density > 0.5:
            anecdote_score = 70
        elif anecdote_density > 0.2:
            anecdote_score = 60
        elif anecdote_density > 0:
            anecdote_score = 50
        else:
            anecdote_score = 30
        
        # Bonus for complete story structure
        if all(count > 0 for count in element_counts.values()):
            anecdote_score += 15
        elif sum(element_counts.values()) > 3:
            anecdote_score += 10
        elif sum(element_counts.values()) > 1:
            anecdote_score += 5
        
        # Bonus for multiple anecdotes
        if anecdote_count >= 2:
            anecdote_score += 10
        
        return round(min(100, anecdote_score), 2)