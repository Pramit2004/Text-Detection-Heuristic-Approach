"""
Scoring Calculator - Complete implementation
Combines all analyzers to produce final scores and classifications
"""

import numpy as np
from typing import Dict, Any, List, Tuple
from collections import defaultdict
import json
import datetime

from ..core.statistical import StatisticalAnalyzer
from ..core.linguistic import LinguisticAnalyzer
from ..core.rhetorical import RhetoricalAnalyzer
from ..core.content import ContentAnalyzer
from ..core.meta import MetaAnalyzer
from .weights import ScoringWeights

class GrandpaDetector:
    """
    Main detector that combines all analyzers to produce comprehensive scores
    """
    
    def __init__(self):
        """Initialize all analyzers"""
        self.statistical = StatisticalAnalyzer()
        self.linguistic = LinguisticAnalyzer()
        self.rhetorical = RhetoricalAnalyzer()
        self.content = ContentAnalyzer()
        self.meta = MetaAnalyzer()
        self.weights = ScoringWeights()
        
        # Classification thresholds
        self.thresholds = {
            'ai_generated': (0, 30),
            'likely_ai': (30, 45),
            'mixed': (45, 65),
            'likely_human': (65, 80),
            'human': (80, 100)
        }
        
        # Confidence levels
        self.confidence_levels = {
            'very_low': (0, 20),
            'low': (20, 40),
            'medium': (40, 60),
            'high': (60, 80),
            'very_high': (80, 100)
        }
    
    def analyze(self, text: str, filename: str = None) -> Dict[str, Any]:
        """
        Complete analysis of text using all analyzers
        Returns comprehensive results with scores and explanations
        """
        if not text or len(text.strip()) < 50:
            return self._get_insufficient_text_response()
        
        # Run all analyzers
        statistical_results = self.statistical.analyze(text)
        linguistic_results = self.linguistic.analyze(text)
        rhetorical_results = self.rhetorical.analyze(text)
        content_results = self.content.analyze(text)
        meta_results = self.meta.analyze(text, filename)
        
        # Calculate category scores
        category_scores = {
            'statistical': statistical_results['statistical_score'],
            'linguistic': linguistic_results['linguistic_score'],
            'rhetorical': rhetorical_results['rhetorical_score'],
            'content': content_results['content_score'],
            'meta': meta_results['meta_score']
        }
        
        # Calculate weighted total score
        total_score = self._calculate_weighted_score(category_scores)
        
        # Calculate confidence score
        confidence = self._calculate_confidence(category_scores)
        
        # Get classification
        classification = self._classify(total_score)
        
        # Generate detailed report
        report = self._generate_report(
            text, 
            category_scores, 
            total_score, 
            classification,
            {
                'statistical': statistical_results,
                'linguistic': linguistic_results,
                'rhetorical': rhetorical_results,
                'content': content_results,
                'meta': meta_results
            }
        )
        
        # Generate improvement suggestions
        suggestions = self._generate_suggestions(
            category_scores,
            {
                'statistical': statistical_results,
                'linguistic': linguistic_results,
                'rhetorical': rhetorical_results,
                'content': content_results,
                'meta': meta_results
            }
        )
        
        return {
            'total_score': round(total_score, 2),
            'confidence': round(confidence, 2),
            'confidence_level': self._get_confidence_level(confidence),
            'category_scores': {k: round(v, 2) for k, v in category_scores.items()},
            'classification': classification,
            'detailed_metrics': {
                'statistical': statistical_results,
                'linguistic': linguistic_results,
                'rhetorical': rhetorical_results,
                'content': content_results,
                'meta': meta_results
            },
            'report': report,
            'suggestions': suggestions,
            'metadata': {
                'analyzed_at': datetime.datetime.now().isoformat(),
                'text_length': len(text),
                'word_count': len(text.split()),
                'filename': filename
            }
        }
    
    def _calculate_weighted_score(self, category_scores: Dict[str, float]) -> float:
        """Calculate weighted total score"""
        total = 0
        for category, score in category_scores.items():
            weight = self.weights.get_category_weight(category)
            total += score * weight
        return total
    
    def _calculate_confidence(self, category_scores: Dict[str, float]) -> float:
        """Calculate confidence score based on consistency across categories"""
        scores = list(category_scores.values())
        
        if not scores:
            return 0
        
        # Calculate variance (lower variance = more consistent = higher confidence)
        variance = np.var(scores)
        
        # Calculate range (smaller range = more consistent)
        score_range = max(scores) - min(scores)
        
        # Calculate number of categories with extreme scores
        extreme_count = sum(1 for s in scores if s < 20 or s > 80)
        
        # Confidence formula
        # Higher when: low variance, small range, few extremes
        base_confidence = 80  # Start high
        
        # Reduce confidence based on variance
        if variance > 500:
            base_confidence -= 30
        elif variance > 300:
            base_confidence -= 20
        elif variance > 150:
            base_confidence -= 10
        
        # Reduce confidence based on range
        if score_range > 50:
            base_confidence -= 20
        elif score_range > 30:
            base_confidence -= 10
        
        # Reduce confidence based on extremes
        base_confidence -= extreme_count * 5
        
        return max(0, min(100, base_confidence))
    
    def _get_confidence_level(self, confidence: float) -> str:
        """Get confidence level description"""
        for level, (low, high) in self.confidence_levels.items():
            if low <= confidence < high:
                return level.replace('_', ' ').title()
        return 'Medium'
    
    def _classify(self, score: float) -> Dict[str, Any]:
        """Classify text based on total score"""
        if score < 30:
            return {
                'label': 'AI-Generated',
                'confidence': 'High',
                'color': 'red',
                'description': 'This text shows strong patterns of AI generation',
                'emoji': '🤖',
                'details': 'The text exhibits characteristics typical of AI writing: uniform structure, repetitive patterns, lack of personal voice, and generic content.'
            }
        elif score < 45:
            return {
                'label': 'Likely AI-Generated',
                'confidence': 'Medium-High',
                'color': 'orange',
                'description': 'This text shows moderate to strong AI patterns',
                'emoji': '⚙️',
                'details': 'The text has several AI-like characteristics but may have some human elements.'
            }
        elif score < 65:
            return {
                'label': 'Mixed / Uncertain',
                'confidence': 'Low',
                'color': 'yellow',
                'description': 'Could be human writing with AI assistance or AI with heavy editing',
                'emoji': '🔄',
                'details': 'The text shows a mix of human and AI characteristics. It may be human-written with AI tools or AI-generated with significant human editing.'
            }
        elif score < 80:
            return {
                'label': 'Likely Human-Written',
                'confidence': 'Medium-High',
                'color': 'lightgreen',
                'description': 'This text shows strong human patterns',
                'emoji': '👤',
                'details': 'The text exhibits many characteristics of human writing: varied structure, personal voice, specific details, and natural flow.'
            }
        else:
            return {
                'label': 'Human-Written',
                'confidence': 'High',
                'color': 'green',
                'description': 'This text shows clear human writing characteristics',
                'emoji': '👨‍💼',
                'details': 'The text strongly exhibits authentic human writing patterns: personal experiences, varied style, emotional depth, and natural inconsistencies.'
            }
    
    def _generate_report(self, text: str, category_scores: Dict[str, float], 
                        total_score: float, classification: Dict[str, Any],
                        detailed_results: Dict[str, Any]) -> str:
        """Generate human-readable report"""
        report = []
        report.append("=" * 60)
        report.append("🤖 GRANDPA TEXT DETECTION REPORT")
        report.append("=" * 60)
        report.append("")
        
        # Overall score
        report.append(f"📊 OVERALL HUMAN SCORE: {total_score:.1f}/100")
        report.append(f"📌 CLASSIFICATION: {classification['emoji']} {classification['label']}")
        report.append(f"📝 {classification['description']}")
        report.append("")
        
        # Confidence
        confidence = self._calculate_confidence(category_scores)
        report.append(f"🎯 CONFIDENCE: {confidence:.1f}% ({self._get_confidence_level(confidence)})")
        report.append("")
        
        # Category breakdown with visual bars
        report.append("📈 CATEGORY BREAKDOWN:")
        report.append("")
        
        for category, score in category_scores.items():
            # Create visual bar
            bar_length = int(score / 5)
            bar = "█" * bar_length + "░" * (20 - bar_length)
            
            # Add category name with proper formatting
            category_name = category.replace('_', ' ').title()
            report.append(f"  {category_name:12}: {bar} {score:.1f}")
        
        report.append("")
        report.append("-" * 60)
        
        # Detailed analysis by category
        report.append("")
        report.append("🔍 DETAILED ANALYSIS:")
        report.append("")
        
        # Statistical details
        stat = detailed_results['statistical']
        report.append("  📊 Statistical Analysis:")
        report.append(f"    • Perplexity: {stat.get('perplexity', {}).get('adjusted_score', 50):.1f}/100 - {'High variation' if stat.get('perplexity', {}).get('adjusted_score', 50) > 70 else 'Low variation' if stat.get('perplexity', {}).get('adjusted_score', 50) < 40 else 'Moderate'}")
        report.append(f"    • Burstiness: {stat.get('burstiness', 50):.1f}/100 - {'Natural rhythm' if stat.get('burstiness', 50) > 70 else 'Uniform rhythm' if stat.get('burstiness', 50) < 40 else 'Moderate'}")
        report.append(f"    • Repetition: {stat.get('repetition', 50):.1f}/100 - {'Good variety' if stat.get('repetition', 50) > 70 else 'Repetitive' if stat.get('repetition', 50) < 40 else 'Moderate'}")
        report.append("")
        
        # Linguistic details
        ling = detailed_results['linguistic']
        report.append("  🗣️ Linguistic Analysis:")
        report.append(f"    • Vocabulary: {ling.get('vocabulary_diversity', 50):.1f}/100 - {'Rich vocabulary' if ling.get('vocabulary_diversity', 50) > 70 else 'Limited vocabulary' if ling.get('vocabulary_diversity', 50) < 40 else 'Moderate'}")
        report.append(f"    • Sentence Structure: {ling.get('sentence_structure', 50):.1f}/100 - {'Varied' if ling.get('sentence_structure', 50) > 70 else 'Uniform' if ling.get('sentence_structure', 50) < 40 else 'Moderate'}")
        report.append(f"    • Hedge Words: {ling.get('hedge_words', 50):.1f}/100 - {'Natural uncertainty' if ling.get('hedge_words', 50) > 60 else 'Too certain' if ling.get('hedge_words', 50) < 30 else 'Moderate'}")
        report.append("")
        
        # Rhetorical details
        rhet = detailed_results['rhetorical']
        report.append("  🎭 Rhetorical Analysis:")
        report.append(f"    • Personal Voice: {rhet.get('personal_voice', 50):.1f}/100 - {'Strong personal voice' if rhet.get('personal_voice', 50) > 70 else 'Impersonal' if rhet.get('personal_voice', 50) < 40 else 'Moderate'}")
        report.append(f"    • Emotional Language: {rhet.get('emotional_language', 50):.1f}/100 - {'Emotionally rich' if rhet.get('emotional_language', 50) > 70 else 'Emotionally flat' if rhet.get('emotional_language', 50) < 40 else 'Moderate'}")
        report.append(f"    • Storytelling: {rhet.get('storytelling', 50):.1f}/100 - {'Uses narratives' if rhet.get('storytelling', 50) > 60 else 'No storytelling' if rhet.get('storytelling', 50) < 30 else 'Some narratives'}")
        report.append("")
        
        # Content details
        cont = detailed_results['content']
        report.append("  📝 Content Analysis:")
        report.append(f"    • Specificity: {cont.get('specificity', 50):.1f}/100 - {'Very specific' if cont.get('specificity', 50) > 70 else 'Generic' if cont.get('specificity', 50) < 40 else 'Moderate'}")
        report.append(f"    • Authenticity: {cont.get('authenticity', 50):.1f}/100 - {'Authentic' if cont.get('authenticity', 50) > 70 else 'Formulaic' if cont.get('authenticity', 50) < 40 else 'Mixed'}")
        report.append(f"    • Examples: {cont.get('examples', 50):.1f}/100 - {'Personal examples' if cont.get('examples', 50) > 70 else 'Generic examples' if cont.get('examples', 50) < 40 else 'Moderate'}")
        report.append("")
        
        # Meta details
        meta = detailed_results['meta']
        report.append("  🔖 Meta Analysis:")
        report.append(f"    • AI Tool Mentions: {meta.get('ai_tool_mentions', {}).get('count', 0)} mentions - {'Suspicious' if meta.get('ai_tool_mentions', {}).get('count', 0) > 0 else 'Clean'}")
        report.append(f"    • Template Patterns: {meta.get('template_indicators', {}).get('count', 0)} patterns found")
        report.append(f"    • Formatting: {meta.get('formatting_patterns', 50):.1f}/100 - {'Natural' if meta.get('formatting_patterns', 50) > 70 else 'Excessive' if meta.get('formatting_patterns', 50) < 40 else 'Moderate'}")
        
        report.append("")
        report.append("-" * 60)
        
        # Key indicators summary
        report.append("")
        report.append("⚠️ KEY INDICATORS:")
        report.append("")
        
        # Collect all indicators
        indicators = self._collect_indicators(detailed_results)
        
        if indicators['ai_indicators']:
            report.append("  AI Indicators:")
            for indicator in indicators['ai_indicators'][:5]:  # Top 5
                report.append(f"    • {indicator}")
        
        if indicators['human_indicators']:
            report.append("")
            report.append("  Human Indicators:")
            for indicator in indicators['human_indicators'][:5]:  # Top 5
                report.append(f"    • {indicator}")
        
        report.append("")
        report.append("=" * 60)
        
        return "\n".join(report)
    
    def _collect_indicators(self, detailed_results: Dict[str, Any]) -> Dict[str, List[str]]:
        """Collect AI and human indicators from detailed results"""
        indicators = {
            'ai_indicators': [],
            'human_indicators': []
        }
        
        # Statistical indicators
        stat = detailed_results.get('statistical', {})
        if stat.get('perplexity', {}).get('adjusted_score', 50) < 40:
            indicators['ai_indicators'].append("Low perplexity (too predictable)")
        elif stat.get('perplexity', {}).get('adjusted_score', 50) > 70:
            indicators['human_indicators'].append("High perplexity (good variation)")
        
        if stat.get('burstiness', 50) < 40:
            indicators['ai_indicators'].append("Low burstiness (uniform sentences)")
        elif stat.get('burstiness', 50) > 70:
            indicators['human_indicators'].append("High burstiness (natural rhythm)")
        
        if stat.get('repetition', 50) < 40:
            indicators['ai_indicators'].append("High repetition (repetitive patterns)")
        elif stat.get('repetition', 50) > 70:
            indicators['human_indicators'].append("Low repetition (good variety)")
        
        # Linguistic indicators
        ling = detailed_results.get('linguistic', {})
        if ling.get('vocabulary_diversity', 50) < 40:
            indicators['ai_indicators'].append("Limited vocabulary")
        elif ling.get('vocabulary_diversity', 50) > 70:
            indicators['human_indicators'].append("Rich vocabulary")
        
        if ling.get('hedge_words', 50) < 30:
            indicators['ai_indicators'].append("No uncertainty markers (overly confident)")
        elif ling.get('hedge_words', 50) > 60:
            indicators['human_indicators'].append("Natural uncertainty (uses hedge words)")
        
        if ling.get('transition_usage', 50) < 40:
            indicators['ai_indicators'].append("Overuses transition phrases")
        
        # Rhetorical indicators
        rhet = detailed_results.get('rhetorical', {})
        if rhet.get('personal_voice', 50) < 40:
            indicators['ai_indicators'].append("Lacks personal voice")
        elif rhet.get('personal_voice', 50) > 70:
            indicators['human_indicators'].append("Strong personal voice")
        
        if rhet.get('emotional_language', 50) < 40:
            indicators['ai_indicators'].append("Emotionally flat")
        elif rhet.get('emotional_language', 50) > 70:
            indicators['human_indicators'].append("Emotionally rich")
        
        if rhet.get('storytelling', 50) > 60:
            indicators['human_indicators'].append("Uses storytelling")
        elif rhet.get('storytelling', 50) < 30:
            indicators['ai_indicators'].append("No narrative elements")
        
        # Content indicators
        cont = detailed_results.get('content', {})
        if cont.get('specificity', 50) < 40:
            indicators['ai_indicators'].append("Generic content (lacks specifics)")
        elif cont.get('specificity', 50) > 70:
            indicators['human_indicators'].append("Specific details and examples")
        
        if cont.get('authenticity', 50) < 40:
            indicators['ai_indicators'].append("Formulaic/inauthentic")
        elif cont.get('authenticity', 50) > 70:
            indicators['human_indicators'].append("Authentic personal voice")
        
        if cont.get('examples', 50) > 70:
            indicators['human_indicators'].append("Personal, relevant examples")
        elif cont.get('examples', 50) < 40:
            indicators['ai_indicators'].append("Generic or missing examples")
        
        # Meta indicators
        meta = detailed_results.get('meta', {})
        ai_mentions = meta.get('ai_tool_mentions', {}).get('count', 0)
        if ai_mentions > 0:
            indicators['ai_indicators'].append(f"Mentions AI tools ({ai_mentions} times)")
        
        templates = meta.get('template_indicators', {}).get('count', 0)
        if templates > 0:
            indicators['ai_indicators'].append(f"Contains template patterns ({templates} found)")
        
        return indicators
    
    def _generate_suggestions(self, category_scores: Dict[str, float], 
                            detailed_results: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Generate improvement suggestions based on low scores"""
        suggestions = []
        
        # Statistical suggestions
        if category_scores.get('statistical', 100) < 60:
            stat = detailed_results.get('statistical', {})
            
            if stat.get('perplexity', {}).get('adjusted_score', 50) < 40:
                suggestions.append({
                    'category': 'statistical',
                    'priority': 'high',
                    'issue': 'Text is too predictable',
                    'suggestion': 'Vary your sentence structure and word choice. Add unexpected elements and creative language.'
                })
            
            if stat.get('burstiness', 50) < 40:
                suggestions.append({
                    'category': 'statistical',
                    'priority': 'medium',
                    'issue': 'Sentences are too uniform in length',
                    'suggestion': 'Mix short and long sentences. Use short sentences for emphasis and longer ones for complex ideas.'
                })
            
            if stat.get('repetition', 50) < 40:
                suggestions.append({
                    'category': 'statistical',
                    'priority': 'high',
                    'issue': 'Repetitive language patterns',
                    'suggestion': 'Use synonyms and vary your phrasing. Avoid repeating the same words and sentence structures.'
                })
        
        # Linguistic suggestions
        if category_scores.get('linguistic', 100) < 60:
            ling = detailed_results.get('linguistic', {})
            
            if ling.get('vocabulary_diversity', 50) < 40:
                suggestions.append({
                    'category': 'linguistic',
                    'priority': 'high',
                    'issue': 'Limited vocabulary',
                    'suggestion': 'Expand your vocabulary. Use more descriptive words and avoid repeating common terms.'
                })
            
            if ling.get('hedge_words', 50) < 30:
                suggestions.append({
                    'category': 'linguistic',
                    'priority': 'medium',
                    'issue': 'Too certain/absolute',
                    'suggestion': 'Add some uncertainty markers like "perhaps," "maybe," or "I think" to sound more natural.'
                })
            
            if ling.get('transition_usage', 50) < 40:
                suggestions.append({
                    'category': 'linguistic',
                    'priority': 'medium',
                    'issue': 'Overuse of transition words',
                    'suggestion': 'Reduce your use of words like "however," "therefore," and "furthermore." Let ideas flow naturally.'
                })
        
        # Rhetorical suggestions
        if category_scores.get('rhetorical', 100) < 60:
            rhet = detailed_results.get('rhetorical', {})
            
            if rhet.get('personal_voice', 50) < 40:
                suggestions.append({
                    'category': 'rhetorical',
                    'priority': 'high',
                    'issue': 'Lacks personal voice',
                    'suggestion': 'Add personal pronouns (I, me, my) and share your perspective. Make it clear this is YOUR writing.'
                })
            
            if rhet.get('emotional_language', 50) < 40:
                suggestions.append({
                    'category': 'rhetorical',
                    'priority': 'medium',
                    'issue': 'Emotionally flat',
                    'suggestion': 'Include emotional language where appropriate. Share how you felt about experiences.'
                })
            
            if rhet.get('storytelling', 50) < 30:
                suggestions.append({
                    'category': 'rhetorical',
                    'priority': 'medium',
                    'issue': 'No storytelling elements',
                    'suggestion': 'Include brief anecdotes or personal stories. Humans connect through narratives.'
                })
        
        # Content suggestions
        if category_scores.get('content', 100) < 60:
            cont = detailed_results.get('content', {})
            
            if cont.get('specificity', 50) < 40:
                suggestions.append({
                    'category': 'content',
                    'priority': 'high',
                    'issue': 'Generic content',
                    'suggestion': 'Add specific details: numbers, dates, names, places. Be concrete rather than abstract.'
                })
            
            if cont.get('authenticity', 50) < 40:
                suggestions.append({
                    'category': 'content',
                    'priority': 'high',
                    'issue': 'Formulaic or inauthentic',
                    'suggestion': 'Share genuine experiences, including challenges and lessons learned. Be honest and vulnerable.'
                })
            
            if cont.get('examples', 50) < 40:
                suggestions.append({
                    'category': 'content',
                    'priority': 'medium',
                    'issue': 'Missing or generic examples',
                    'suggestion': 'Include specific, personal examples. Instead of "for example," share a real experience.'
                })
        
        # Meta suggestions
        if category_scores.get('meta', 100) < 60:
            meta = detailed_results.get('meta', {})
            
            ai_mentions = meta.get('ai_tool_mentions', {}).get('count', 0)
            if ai_mentions > 0:
                suggestions.append({
                    'category': 'meta',
                    'priority': 'high',
                    'issue': 'Mentions AI tools',
                    'suggestion': 'Remove any mentions of AI tools or generators. Write in your own voice.'
                })
            
            templates = meta.get('template_indicators', {}).get('count', 0)
            if templates > 0:
                suggestions.append({
                    'category': 'meta',
                    'priority': 'high',
                    'issue': 'Contains template patterns',
                    'suggestion': 'Remove placeholder text like [Your Name]. Customize all sections personally.'
                })
        
        # Sort by priority
        priority_order = {'high': 0, 'medium': 1, 'low': 2}
        suggestions.sort(key=lambda x: priority_order.get(x['priority'], 3))
        
        return suggestions
    
    def _get_insufficient_text_response(self) -> Dict[str, Any]:
        """Return response for insufficient text"""
        return {
            'total_score': 50.0,
            'confidence': 0,
            'confidence_level': 'Very Low',
            'category_scores': {
                'statistical': 50.0,
                'linguistic': 50.0,
                'rhetorical': 50.0,
                'content': 50.0,
                'meta': 50.0
            },
            'classification': {
                'label': 'Insufficient Text',
                'confidence': 'N/A',
                'color': 'gray',
                'description': 'Text is too short for reliable analysis (minimum 50 characters)',
                'emoji': '⚠️',
                'details': 'Please provide more text (at least 50 characters) for accurate detection.'
            },
            'detailed_metrics': {},
            'report': "⚠️ INSUFFICIENT TEXT: Please provide at least 50 characters for reliable analysis.",
            'suggestions': [
                {
                    'category': 'general',
                    'priority': 'high',
                    'issue': 'Text too short',
                    'suggestion': 'Provide at least 50 characters of text for meaningful analysis.'
                }
            ],
            'metadata': {
                'analyzed_at': datetime.datetime.now().isoformat(),
                'text_length': 0,
                'word_count': 0,
                'filename': None
            }
        }
    
    def analyze_batch(self, texts: List[str]) -> List[Dict[str, Any]]:
        """Analyze multiple texts in batch"""
        results = []
        for text in texts:
            results.append(self.analyze(text))
        return results
    
    def compare_texts(self, text1: str, text2: str) -> Dict[str, Any]:
        """Compare two texts and analyze differences"""
        result1 = self.analyze(text1)
        result2 = self.analyze(text2)
        
        comparison = {
            'text1_score': result1['total_score'],
            'text2_score': result2['total_score'],
            'difference': abs(result1['total_score'] - result2['total_score']),
            'text1_classification': result1['classification']['label'],
            'text2_classification': result2['classification']['label'],
            'more_human_like': 'text1' if result1['total_score'] > result2['total_score'] else 'text2',
            'category_comparison': {}
        }
        
        # Compare category scores
        for category in result1['category_scores']:
            comparison['category_comparison'][category] = {
                'text1': result1['category_scores'][category],
                'text2': result2['category_scores'][category],
                'difference': abs(result1['category_scores'][category] - result2['category_scores'][category])
            }
        
        return comparison