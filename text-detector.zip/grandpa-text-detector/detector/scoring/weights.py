"""
Scoring Weights - Complete implementation
Defines all weights for scoring categories and subcategories
"""

class ScoringWeights:
    """
    Defines weights for different scoring categories and subcategories
    These weights are optimized based on research and testing
    """
    
    # Main category weights - Total must sum to 1.0
    CATEGORY_WEIGHTS = {
        'statistical': 0.25,  # Statistical patterns (perplexity, burstiness, etc.)
        'linguistic': 0.25,   # Linguistic patterns (vocabulary, grammar, etc.)
        'rhetorical': 0.20,    # Rhetorical patterns (argument, voice, etc.)
        'content': 0.20,       # Content patterns (specificity, examples, etc.)
        'meta': 0.10           # Metadata patterns (AI mentions, templates, etc.)
    }
    
    # Statistical subcategory weights
    STATISTICAL_WEIGHTS = {
        'perplexity': 0.30,     # Word predictability
        'burstiness': 0.25,      # Sentence length variation
        'repetition': 0.20,      # Repetitive patterns
        'entropy': 0.15,         # Information entropy
        'zipf_coefficient': 0.05, # Zipf's law compliance
        'function_word_ratio': 0.05  # Function word usage
    }
    
    # Linguistic subcategory weights
    LINGUISTIC_WEIGHTS = {
        'sentence_structure': 0.20,   # Sentence complexity and variation
        'vocabulary_diversity': 0.25,  # Vocabulary richness
        'transition_usage': 0.15,      # Transition word usage
        'hedge_words': 0.20,           # Uncertainty markers
        'complex_sentences': 0.10,      # Complex sentence structures
        'sentence_starters': 0.10       # Sentence opening variety
    }
    
    # Rhetorical subcategory weights
    RHETORICAL_WEIGHTS = {
        'personal_voice': 0.30,        # Personal pronouns and subjectivity
        'argument_structure': 0.20,     # Argument flow and evidence
        'tone_consistency': 0.15,       # Tone variation
        'emotional_language': 0.15,     # Emotional word usage
        'storytelling': 0.10,           # Narrative elements
        'rhetorical_questions': 0.10     # Question usage
    }
    
    # Content subcategory weights
    CONTENT_WEIGHTS = {
        'specificity': 0.25,        # Specific details and numbers
        'examples': 0.25,            # Quality of examples
        'authenticity': 0.25,        # Genuine human elements
        'factual_density': 0.15,      # Factual information
        'concrete_ratio': 0.10        # Concrete vs abstract words
    }
    
    # Meta subcategory weights
    META_WEIGHTS = {
        'ai_tool_mentions': 0.20,     # Mentions of AI tools
        'template_indicators': 0.20,   # Template patterns
        'document_structure': 0.15,    # Document organization
        'disclaimers': 0.15,           # AI disclaimers
        'formatting_patterns': 0.15,    # Formatting consistency
        'digital_fingerprints': 0.15    # Digital artifacts
    }
    
    # Confidence thresholds for different classification levels
    CLASSIFICATION_THRESHOLDS = {
        'ai_generated': (0, 30),
        'likely_ai': (30, 45),
        'mixed': (45, 65),
        'likely_human': (65, 80),
        'human': (80, 100)
    }
    
    # Confidence level thresholds
    CONFIDENCE_LEVELS = {
        'very_low': (0, 20),
        'low': (20, 40),
        'medium': (40, 60),
        'high': (60, 80),
        'very_high': (80, 100)
    }
    
    # Priority levels for suggestions
    PRIORITY_LEVELS = {
        'high': 1,
        'medium': 2,
        'low': 3
    }
    
    @classmethod
    def get_all_weights(cls) -> dict:
        """
        Get complete weight configuration
        Returns dictionary with all weights
        """
        return {
            'categories': cls.CATEGORY_WEIGHTS,
            'statistical': cls.STATISTICAL_WEIGHTS,
            'linguistic': cls.LINGUISTIC_WEIGHTS,
            'rhetorical': cls.RHETORICAL_WEIGHTS,
            'content': cls.CONTENT_WEIGHTS,
            'meta': cls.META_WEIGHTS
        }
    
    @classmethod
    def get_category_weight(cls, category: str) -> float:
        """
        Get weight for a specific category
        Args:
            category: Category name (statistical, linguistic, rhetorical, content, meta)
        Returns:
            Weight value (0-1)
        """
        return cls.CATEGORY_WEIGHTS.get(category, 0)
    
    @classmethod
    def get_subcategory_weights(cls, category: str) -> dict:
        """
        Get weights for subcategories of a specific category
        Args:
            category: Category name
        Returns:
            Dictionary of subcategory weights
        """
        weight_map = {
            'statistical': cls.STATISTICAL_WEIGHTS,
            'linguistic': cls.LINGUISTIC_WEIGHTS,
            'rhetorical': cls.RHETORICAL_WEIGHTS,
            'content': cls.CONTENT_WEIGHTS,
            'meta': cls.META_WEIGHTS
        }
        return weight_map.get(category, {})
    
    @classmethod
    def get_subcategory_weight(cls, category: str, subcategory: str) -> float:
        """
        Get weight for a specific subcategory
        Args:
            category: Category name
            subcategory: Subcategory name
        Returns:
            Weight value (0-1)
        """
        subcategory_weights = cls.get_subcategory_weights(category)
        return subcategory_weights.get(subcategory, 0)
    
    @classmethod
    def validate_weights(cls) -> bool:
        """
        Validate that all weights sum to 1.0 within each category
        Returns:
            True if all weights are valid, False otherwise
        """
        # Check main category weights
        main_sum = sum(cls.CATEGORY_WEIGHTS.values())
        if abs(main_sum - 1.0) > 0.01:  # Allow small rounding error
            print(f"Warning: Main category weights sum to {main_sum}, should be 1.0")
            return False
        
        # Check statistical subcategory weights
        stat_sum = sum(cls.STATISTICAL_WEIGHTS.values())
        if abs(stat_sum - 1.0) > 0.01:
            print(f"Warning: Statistical weights sum to {stat_sum}, should be 1.0")
            return False
        
        # Check linguistic subcategory weights
        ling_sum = sum(cls.LINGUISTIC_WEIGHTS.values())
        if abs(ling_sum - 1.0) > 0.01:
            print(f"Warning: Linguistic weights sum to {ling_sum}, should be 1.0")
            return False
        
        # Check rhetorical subcategory weights
        rhet_sum = sum(cls.RHETORICAL_WEIGHTS.values())
        if abs(rhet_sum - 1.0) > 0.01:
            print(f"Warning: Rhetorical weights sum to {rhet_sum}, should be 1.0")
            return False
        
        # Check content subcategory weights
        cont_sum = sum(cls.CONTENT_WEIGHTS.values())
        if abs(cont_sum - 1.0) > 0.01:
            print(f"Warning: Content weights sum to {cont_sum}, should be 1.0")
            return False
        
        # Check meta subcategory weights
        meta_sum = sum(cls.META_WEIGHTS.values())
        if abs(meta_sum - 1.0) > 0.01:
            print(f"Warning: Meta weights sum to {meta_sum}, should be 1.0")
            return False
        
        return True
    
    @classmethod
    def get_classification_threshold(cls, classification: str) -> tuple:
        """
        Get threshold range for a classification
        Args:
            classification: Classification name (ai_generated, likely_ai, etc.)
        Returns:
            Tuple of (min, max) thresholds
        """
        return cls.CLASSIFICATION_THRESHOLDS.get(classification, (0, 100))
    
    @classmethod
    def get_classification(cls, score: float) -> str:
        """
        Get classification for a score
        Args:
            score: Total score (0-100)
        Returns:
            Classification name
        """
        for classification, (min_score, max_score) in cls.CLASSIFICATION_THRESHOLDS.items():
            if min_score <= score < max_score:
                return classification
        return 'mixed'  # Default
    
    @classmethod
    def get_confidence_level(cls, confidence: float) -> str:
        """
        Get confidence level for a confidence score
        Args:
            confidence: Confidence score (0-100)
        Returns:
            Confidence level name
        """
        for level, (min_conf, max_conf) in cls.CONFIDENCE_LEVELS.items():
            if min_conf <= confidence < max_conf:
                return level
        return 'medium'  # Default
    
    @classmethod
    def get_priority_level(cls, priority: str) -> int:
        """
        Get numeric priority level
        Args:
            priority: Priority name (high, medium, low)
        Returns:
            Numeric priority (1=high, 2=medium, 3=low)
        """
        return cls.PRIORITY_LEVELS.get(priority, 3)
    
    @classmethod
    def get_category_description(cls, category: str) -> str:
        """
        Get description for a category
        Args:
            category: Category name
        Returns:
            Description string
        """
        descriptions = {
            'statistical': 'Measures statistical patterns like word predictability, sentence length variation, and repetition',
            'linguistic': 'Analyzes linguistic features like vocabulary diversity, sentence structure, and natural language patterns',
            'rhetorical': 'Evaluates rhetorical elements like personal voice, emotional language, and storytelling',
            'content': 'Assesses content quality including specificity, authenticity, and use of examples',
            'meta': 'Examines metadata and digital fingerprints like AI tool mentions and template patterns'
        }
        return descriptions.get(category, 'No description available')
    
    @classmethod
    def get_subcategory_description(cls, category: str, subcategory: str) -> str:
        """
        Get description for a subcategory
        Args:
            category: Category name
            subcategory: Subcategory name
        Returns:
            Description string
        """
        descriptions = {
            'statistical': {
                'perplexity': 'How predictable the word choices are - lower values suggest AI',
                'burstiness': 'Variation in sentence lengths - higher values suggest human',
                'repetition': 'Frequency of repeated patterns - lower values suggest human',
                'entropy': 'Information density and randomness - higher values suggest human',
                'zipf_coefficient': 'How well word frequencies follow Zipf\'s law - closer to -1 suggests human',
                'function_word_ratio': 'Usage of function words like "the", "and" - moderate values suggest human'
            },
            'linguistic': {
                'sentence_structure': 'Complexity and variation in sentence construction',
                'vocabulary_diversity': 'Richness and variety of word choice',
                'transition_usage': 'Use of transition words like "however", "therefore"',
                'hedge_words': 'Use of uncertainty markers like "perhaps", "maybe"',
                'complex_sentences': 'Frequency of complex sentence structures',
                'sentence_starters': 'Variety in how sentences begin'
            },
            'rhetorical': {
                'personal_voice': 'Use of personal pronouns and subjective expressions',
                'argument_structure': 'Organization of claims, evidence, and conclusions',
                'tone_consistency': 'Natural variation in tone throughout the text',
                'emotional_language': 'Use of emotionally charged words',
                'storytelling': 'Presence of narrative elements and anecdotes',
                'rhetorical_questions': 'Use of questions for rhetorical effect'
            },
            'content': {
                'specificity': 'Use of specific details, numbers, and proper nouns',
                'examples': 'Quality and relevance of examples provided',
                'authenticity': 'Genuine human elements like vulnerability and personal experiences',
                'factual_density': 'Amount of factual information and data',
                'concrete_ratio': 'Balance between concrete and abstract language'
            },
            'meta': {
                'ai_tool_mentions': 'Explicit mentions of AI tools or generators',
                'template_indicators': 'Presence of placeholder text like [Your Name]',
                'document_structure': 'Organization and section headers',
                'disclaimers': 'AI disclaimers like "as an AI language model"',
                'formatting_patterns': 'Consistency and type of formatting used',
                'digital_fingerprints': 'Digital artifacts like Unicode characters or whitespace patterns'
            }
        }
        
        category_desc = descriptions.get(category, {})
        return category_desc.get(subcategory, 'No description available')
    
    @classmethod
    def get_default_weights(cls) -> dict:
        """
        Get default weights (current configuration)
        Returns:
            Dictionary with all default weights
        """
        return {
            'categories': cls.CATEGORY_WEIGHTS.copy(),
            'statistical': cls.STATISTICAL_WEIGHTS.copy(),
            'linguistic': cls.LINGUISTIC_WEIGHTS.copy(),
            'rhetorical': cls.RHETORICAL_WEIGHTS.copy(),
            'content': cls.CONTENT_WEIGHTS.copy(),
            'meta': cls.META_WEIGHTS.copy()
        }
    
    @classmethod
    def get_experimental_weights(cls) -> dict:
        """
        Get experimental weight configuration (for testing)
        Returns:
            Dictionary with experimental weights
        """
        return {
            'categories': {
                'statistical': 0.20,
                'linguistic': 0.20,
                'rhetorical': 0.20,
                'content': 0.20,
                'meta': 0.20
            },
            'statistical': {
                'perplexity': 0.25,
                'burstiness': 0.25,
                'repetition': 0.25,
                'entropy': 0.25
            },
            'linguistic': {
                'vocabulary_diversity': 0.30,
                'sentence_structure': 0.30,
                'hedge_words': 0.40
            },
            'rhetorical': {
                'personal_voice': 0.40,
                'emotional_language': 0.30,
                'storytelling': 0.30
            },
            'content': {
                'specificity': 0.35,
                'authenticity': 0.35,
                'examples': 0.30
            },
            'meta': {
                'ai_tool_mentions': 0.25,
                'template_indicators': 0.25,
                'disclaimers': 0.25,
                'digital_fingerprints': 0.25
            }
        }
    
    @classmethod
    def get_weights_for_document_type(cls, doc_type: str) -> dict:
        """
        Get optimized weights for specific document types
        Args:
            doc_type: Type of document (essay, email, resume, creative, etc.)
        Returns:
            Dictionary with customized weights
        """
        weights = cls.get_default_weights()
        
        if doc_type == 'essay':
            # Academic essays value argument structure and factual content
            weights['categories']['rhetorical'] = 0.25
            weights['categories']['content'] = 0.25
            weights['categories']['statistical'] = 0.20
            weights['categories']['linguistic'] = 0.20
            weights['categories']['meta'] = 0.10
            
        elif doc_type == 'email':
            # Emails value personal voice and authenticity
            weights['categories']['rhetorical'] = 0.30
            weights['categories']['content'] = 0.25
            weights['categories']['linguistic'] = 0.20
            weights['categories']['statistical'] = 0.15
            weights['categories']['meta'] = 0.10
            
        elif doc_type == 'resume':
            # Resumes value specificity and factual content
            weights['categories']['content'] = 0.35
            weights['categories']['statistical'] = 0.25
            weights['categories']['linguistic'] = 0.20
            weights['categories']['meta'] = 0.20
            weights['categories']['rhetorical'] = 0.00  # Less relevant for resumes
            
        elif doc_type == 'creative':
            # Creative writing values rhetorical and linguistic features
            weights['categories']['rhetorical'] = 0.35
            weights['categories']['linguistic'] = 0.30
            weights['categories']['statistical'] = 0.20
            weights['categories']['content'] = 0.15
            weights['categories']['meta'] = 0.00
            
        elif doc_type == 'technical':
            # Technical writing values precision and factual content
            weights['categories']['content'] = 0.35
            weights['categories']['statistical'] = 0.25
            weights['categories']['linguistic'] = 0.20
            weights['categories']['meta'] = 0.20
            weights['categories']['rhetorical'] = 0.00
            
        elif doc_type == 'social_media':
            # Social media values personal voice and authenticity
            weights['categories']['rhetorical'] = 0.35
            weights['categories']['content'] = 0.30
            weights['categories']['linguistic'] = 0.20
            weights['categories']['statistical'] = 0.15
            weights['categories']['meta'] = 0.00
        
        return weights
    
    @classmethod
    def print_weight_summary(cls):
        """Print a summary of all weights for debugging"""
        print("\n" + "="*50)
        print("SCORING WEIGHTS SUMMARY")
        print("="*50)
        
        # Main categories
        print("\n📊 MAIN CATEGORY WEIGHTS:")
        for category, weight in cls.CATEGORY_WEIGHTS.items():
            bar = "█" * int(weight * 50)
            print(f"  {category.capitalize():12}: {bar} {weight:.2f}")
        
        # Statistical subcategories
        print("\n📈 STATISTICAL SUBWEIGHTS:")
        for subcat, weight in cls.STATISTICAL_WEIGHTS.items():
            bar = "█" * int(weight * 50)
            print(f"  {subcat.replace('_', ' '):20}: {bar} {weight:.2f}")
        
        # Linguistic subcategories
        print("\n🗣️ LINGUISTIC SUBWEIGHTS:")
        for subcat, weight in cls.LINGUISTIC_WEIGHTS.items():
            bar = "█" * int(weight * 50)
            print(f"  {subcat.replace('_', ' '):20}: {bar} {weight:.2f}")
        
        # Rhetorical subcategories
        print("\n🎭 RHETORICAL SUBWEIGHTS:")
        for subcat, weight in cls.RHETORICAL_WEIGHTS.items():
            bar = "█" * int(weight * 50)
            print(f"  {subcat.replace('_', ' '):20}: {bar} {weight:.2f}")
        
        # Content subcategories
        print("\n📝 CONTENT SUBWEIGHTS:")
        for subcat, weight in cls.CONTENT_WEIGHTS.items():
            bar = "█" * int(weight * 50)
            print(f"  {subcat.replace('_', ' '):20}: {bar} {weight:.2f}")
        
        # Meta subcategories
        print("\n🔖 META SUBWEIGHTS:")
        for subcat, weight in cls.META_WEIGHTS.items():
            bar = "█" * int(weight * 50)
            print(f"  {subcat.replace('_', ' '):20}: {bar} {weight:.2f}")
        
        print("\n" + "="*50)
        
        # Validation
        if cls.validate_weights():
            print("✅ All weights are valid (sum to 1.0)")
        else:
            print("❌ Weight validation failed")