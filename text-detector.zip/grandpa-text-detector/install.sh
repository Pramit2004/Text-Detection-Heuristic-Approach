#!/bin/bash

echo "🔧 Installing Grandpa Text Detector dependencies..."

# Create virtual environment
echo "📦 Creating virtual environment..."
python -m venv venv
source venv/bin/activate

# Upgrade pip and install build tools first
echo "🔨 Installing build tools..."
pip install --upgrade pip setuptools wheel

# Install requirements in groups
echo "📚 Installing web framework..."
pip install fastapi==0.104.1 uvicorn[standard]==0.24.0 python-multipart==0.0.6

echo "📄 Installing file processors..."
pip install PyPDF2==3.0.1 python-docx==0.8.11

echo "🧠 Installing NLP packages..."
pip install nltk==3.8.1 spacy==3.7.2

echo "📊 Installing data science packages..."
pip install numpy==1.24.3 pandas==2.1.3 scikit-learn==1.3.2

# Download NLTK data
echo "📥 Downloading NLTK data..."
python -c "import nltk; nltk.download('punkt')"

# Download spaCy model
echo "📥 Downloading spaCy model..."
python -m spacy download en_core_web_sm

echo "✅ Installation complete!"
echo "🚀 Run the app with: python app.py"
